﻿using System;
using System.Windows.Forms;

namespace MetricsSuiteVision
{
    public partial class LanguageSelection : Form
    {
        public int tabIndex;
        private frmMetricsSuite mainForm = null;
        public LanguageSelection(Form frmCallingFrom)
        {
            InitializeComponent();

            try
            {
                mainForm = frmCallingFrom as frmMetricsSuite;
                tabIndex = -1;

                foreach (Control c in mainForm.Controls)
                {
                    if (c is TabControl)
                    {
                        TabControl tb = (TabControl)c;
                        foreach (TabPage tp in tb.TabPages)
                            if (tp.Text != "SMI")
                                tabIndex = tb.SelectedIndex;
                    };
                }

                if (tabIndex != -1)
                {
                    foreach (Control control in this.gbLanguage.Controls)
                    {
                        if (control is RadioButton)
                        {
                            if (frmMetricsSuite.metricsSuiteMain != null)
                            {
                                if (frmMetricsSuite.metricsSuiteMain.FunctionPoint != null)
                                {
                                    for (int i = 0; i <= frmMetricsSuite.metricsSuiteMain.FunctionPoint.Count - 1; i++)
                                        if (tabIndex == frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].TabIndex)
                                            tabIndex = i;
                                    if (control.Text == frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].SelectedLanguage)
                                    {
                                        RadioButton radio = control as RadioButton;
                                        radio.Checked = true;
                                    }
                                }
                                else if (control.Text == frmMetricsSuite.sSelectedLanguage)
                                {
                                    RadioButton radio = control as RadioButton;
                                    radio.Checked = true;
                                }
                            }
                            else if (control.Text == frmMetricsSuite.sSelectedLanguage)
                            {
                                RadioButton radio = control as RadioButton;
                                radio.Checked = true;
                            }
                        }
                    }
                }
                else
                {
                    foreach (Control control in this.gbLanguage.Controls)
                    {
                        if (control is RadioButton)
                        {
                            RadioButton radio = control as RadioButton;
                            if (radio.Text == frmMetricsSuite.sSelectedLanguage)
                            {
                                radio.Checked = true;
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error Occurred!", "Error Message");
            }
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < frmMetricsSuite.metricsSuiteMain.FunctionPoint.Count - 1; i++)
                    if (tabIndex == frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].TabIndex)
                        tabIndex = i;


                foreach (Control control in this.gbLanguage.Controls)
                {
                    // Setting values of selected language in global variables
                    if (control is RadioButton)
                    {
                        RadioButton radio = control as RadioButton;
                        if (radio.Checked)
                        {
                            if (frmMetricsSuite.metricsSuiteMain != null && tabIndex != -1)
                            {
                                if (frmMetricsSuite.metricsSuiteMain.FunctionPoint != null)
                                    frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].SelectedLanguage = radio.Text;
                            }

                            frmMetricsSuite.sSelectedLanguage = radio.Text;
                        }
                    }
                }

                Form frm = (frmMetricsSuite)Application.OpenForms["frmMetricsSuite"];
                if (frm != null)
                {
                    foreach (Control c in frm.Controls)
                    {
                        if (c is TabControl)
                        {
                            foreach (Control tc in c.Controls)
                            {
                                if (tc is TabPage && tc.TabIndex == tabIndex)
                                {
                                    foreach (Control pc in tc.Controls)
                                    {
                                        if (pc is FunctionPoints)
                                        {
                                            FunctionPoints functionPoints = (FunctionPoints)pc;

                                            foreach (Control fc in functionPoints.Controls)
                                            {
                                                if (fc is Label && fc.Name == "lbSelectedLanguage")
                                                {
                                                    fc.Text = frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].SelectedLanguage;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    this.Close();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occurred!", "Error Message");
            }
        }
    }
}
