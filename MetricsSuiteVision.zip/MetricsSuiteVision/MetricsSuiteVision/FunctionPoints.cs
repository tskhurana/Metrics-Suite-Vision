﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Linq;

namespace MetricsSuiteVision
{
    public partial class FunctionPoints : UserControl
    {
        public int tabIndex;
        private frmMetricsSuite mainForm = null;

        /// <summary>
        /// Constructor to load the form with all values
        /// </summary>
        /// <param name="frmCallingFrom">Object of form that is calling this constructor</param>
        /// <param name="i">Optional variable to have index value of current tab</param>
        public FunctionPoints(Form frmCallingFrom, int i = -1)
        {
            InitializeComponent();
            mainForm = frmCallingFrom as frmMetricsSuite;

            try
            {
                if (i != -1)
                {
                    if (frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].SelectedLanguage != null)
                    {
                        txtExternalInputs.Text = frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].ExernalInputs.ToString();
                        txtExternalOutputs.Text = frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].ExternalOutputs.ToString();
                        txtExternalInquiries.Text = frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].ExternalInquiries.ToString();
                        txtInternalLogicalFiles.Text = frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].InternalLogicalFiles.ToString();
                        txtExternalInterfaceFiles.Text = frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].ExternalInterfaceFiles.ToString();

                        SetRadioButtonValue(gbExternalInputs, frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].ExernalInputComplexity);
                        SetRadioButtonValue(gbExternalOutputs, frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].ExternalOutputComplexity);
                        SetRadioButtonValue(gbExternalInquiries, frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].ExternalInquirieComplexity);
                        SetRadioButtonValue(gbInternalLogicalFiles, frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].InternalLogicalFileComplexity);
                        SetRadioButtonValue(gbExternalInterfaceFiles, frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].ExternalInterfaceFileComplexity);

                        // Calculate External Inputs
                        int iExternalInputs = Convert.ToInt32(txtExternalInputs.Text) * frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].ExernalInputComplexity;
                        int iExternalOutputs = Convert.ToInt32(txtExternalOutputs.Text) * frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].ExternalOutputComplexity;
                        int iExternalInquiries = Convert.ToInt32(txtExternalInquiries.Text) * frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].ExternalInquirieComplexity;
                        int iInternalLogicalFiles = Convert.ToInt32(txtInternalLogicalFiles.Text) * frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].InternalLogicalFileComplexity;
                        int iExternalInterfaceFiles = Convert.ToInt32(txtExternalInterfaceFiles.Text) * frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].ExternalInterfaceFileComplexity;
                        int iCountTotal = iExternalInputs + iExternalOutputs + iExternalInquiries + iInternalLogicalFiles + iExternalInterfaceFiles;

                        lbExternalInputsValue.Text = iExternalInputs.ToString("N0");
                        lbExternalOutputsValue.Text = iExternalOutputs.ToString("N0");
                        lbExternalInquiriesValue.Text = iExternalInquiries.ToString("N0");
                        lbInternalLogicalFilesValue.Text = iInternalLogicalFiles.ToString("N0");
                        lbExternalInterfaceFilesValue.Text = iExternalInterfaceFiles.ToString("N0");
                        lbTotalCountValue.Text = iCountTotal.ToString("N0");

                        lbFuntionPoint.Text = String.Format("{0:n}", frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].FpCount.ToString());
                        lbValueAdjustments.Text = frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].ValueAdjustments.ToString("N0");
                        lbCodeSize.Text = frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].EstimatedCodeSize.ToString("N0");
                    }

                    lbSelectedLanguage.Text = frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].SelectedLanguage;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occurred!", "Error Message");
            }
        }

        private void btnChangeLanguage_Click(object sender, EventArgs e)
        {
            LanguageSelection languageSelection = new LanguageSelection(mainForm);
            languageSelection.ShowDialog();
        }

        private void btnComputeFP_Click(object sender, EventArgs e)
        {
            foreach (Control c in mainForm.Controls)
                if (c is TabControl)
                {
                    TabControl tc = (TabControl)c;
                    tabIndex = tc.SelectedIndex;
                }

            for (int i = 0; i <= frmMetricsSuite.metricsSuiteMain.FunctionPoint.Count - 1; i++)
                if (tabIndex == frmMetricsSuite.metricsSuiteMain.FunctionPoint[i].TabIndex)
                    tabIndex = i;

            if (frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].SelectedLanguage == string.Empty)
                MessageBox.Show("Please select a language!", "Error Message");
            else
            {
                try
                {
                    // Setting input variables
                    frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].ExernalInputs = Convert.ToInt32(txtExternalInputs.Text);
                    frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].ExternalOutputs = Convert.ToInt32(txtExternalOutputs.Text);
                    frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].ExternalInquiries = Convert.ToInt32(txtExternalInquiries.Text);
                    frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].InternalLogicalFiles = Convert.ToInt32(txtInternalLogicalFiles.Text);
                    frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].ExternalInterfaceFiles = Convert.ToInt32(txtExternalInterfaceFiles.Text);

                    frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].ExernalInputComplexity = GetRadioButtonValue(gbExternalInputs);
                    frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].ExternalOutputComplexity = GetRadioButtonValue(gbExternalOutputs);
                    frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].ExternalInquirieComplexity = GetRadioButtonValue(gbExternalInquiries);
                    frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].InternalLogicalFileComplexity = GetRadioButtonValue(gbInternalLogicalFiles);
                    frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].ExternalInterfaceFileComplexity = GetRadioButtonValue(gbExternalInterfaceFiles);

                    // Calculate External Inputs
                    int iExternalInputs = Convert.ToInt32(txtExternalInputs.Text) * GetRadioButtonValue(gbExternalInputs);
                    int iExternalOutputs = Convert.ToInt32(txtExternalOutputs.Text) * GetRadioButtonValue(gbExternalOutputs);
                    int iExternalInquiries = Convert.ToInt32(txtExternalInquiries.Text) * GetRadioButtonValue(gbExternalInquiries);
                    int iInternalLogicalFiles = Convert.ToInt32(txtInternalLogicalFiles.Text) * GetRadioButtonValue(gbInternalLogicalFiles);
                    int iExternalInterfaceFiles = Convert.ToInt32(txtExternalInterfaceFiles.Text) * GetRadioButtonValue(gbExternalInterfaceFiles);
                    int iCountTotal = iExternalInputs + iExternalOutputs + iExternalInquiries + iInternalLogicalFiles + iExternalInterfaceFiles;

                    lbExternalInputsValue.Text = iExternalInputs.ToString();
                    lbExternalOutputsValue.Text = iExternalOutputs.ToString();
                    lbExternalInquiriesValue.Text = iExternalInquiries.ToString();
                    lbInternalLogicalFilesValue.Text = iInternalLogicalFiles.ToString();
                    lbExternalInterfaceFilesValue.Text = iExternalInterfaceFiles.ToString();
                    lbTotalCountValue.Text = iCountTotal.ToString();

                    int sumFI = frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].ValueAdjustments;

                    double iFunctionPoints = iCountTotal * (0.65 + (0.01 * sumFI));
                    lbFuntionPoint.Text = String.Format("{0:n}", iFunctionPoints.ToString());
                    frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].FpCount = iFunctionPoints;

                    lbSelectedLanguage.Text = frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].SelectedLanguage;
                    lbValueAdjustments.Text = frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].ValueAdjustments.ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("Please enter all the values!", "Error Message");
                }
            }
        }

        private int GetRadioButtonValue(GroupBox groupBox)
        {
            // Gets the object of checked radio button in supplied groupbox
            var checkedButton = groupBox.Controls.OfType<RadioButton>()
                                  .FirstOrDefault(r => r.Checked);

            return Convert.ToInt32(checkedButton.Text);
        }

        private void SetRadioButtonValue(GroupBox groupBox, int value)
        {
            // Gets object of radio button with text property equsl to value in supplied groupbox
            var checkedButton = groupBox.Controls.OfType<RadioButton>()
                                  .FirstOrDefault(r => r.Text.Equals(value.ToString()));

            checkedButton.Checked = true;
        }

        private void btnValueAdjustments_Click(object sender, EventArgs e)
        {
            ValueAdjustmentFactors valueAdjustmentFactors = new ValueAdjustmentFactors(mainForm);
            valueAdjustmentFactors.ShowDialog();
        }

        private void btnComputeCodeSize_Click(object sender, EventArgs e)
        {
            try
            {
                int iAverageCodeSize = 0;
                XElement root = XElement.Load(@"C:\Users\Tejveer\source\repos\MetricsSuiteVision\MetricsSuiteVision\LOCPerFPByLanguage.xml");
                IEnumerable<XElement> address = from el in root.Elements(GetFormatedLanguage(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].SelectedLanguage))
                                                select el;
                foreach (XElement elm in address.Nodes())
                    if (elm.Name.ToString() == "avg")
                        iAverageCodeSize = Convert.ToInt32(elm.Value);

                Int64 iEstimatedCodeSize = Convert.ToInt64(Math.Round(iAverageCodeSize * frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].FpCount));
                lbCodeSize.Text = iEstimatedCodeSize.ToString("N0");

                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].EstimatedCodeSize = iEstimatedCodeSize;
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occurred!", "Error Message");
            }
        }

        private string GetFormatedLanguage(string sLanguage)
        {
            if (sLanguage == "ADA 95")
                sLanguage = "Ada";
            else if (sLanguage == "C++")
                sLanguage = "CPP";
            else if (sLanguage == "C#")
                sLanguage = "CSharp";
            else if (sLanguage == "Visual Basic")
                sLanguage = "VisualBasic";

            return sLanguage;
        }

        private void txtExternalInputs_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            { e.Handled = true; }
        }

        private void txtExternalOutputs_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            { e.Handled = true; }
        }

        private void txtExternalInquiries_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            { e.Handled = true; }
        }

        private void txtInternalLogicalFiles_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            { e.Handled = true; }
        }

        private void txtExternalInterfaceFiles_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            { e.Handled = true; }
        }
    }
}
