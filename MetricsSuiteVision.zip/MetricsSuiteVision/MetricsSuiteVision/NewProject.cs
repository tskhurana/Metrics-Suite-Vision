﻿using System;
using System.Text;
using System.Windows.Forms;

namespace MetricsSuiteVision
{
    public partial class NewProject : Form
    {
        public NewProject()
        {
            InitializeComponent();
        }

        private frmMetricsSuite mainForm = null;
        public NewProject(Form frmCallingFrom)
        {
            mainForm = frmCallingFrom as frmMetricsSuite;
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                StringBuilder sbMessage = new StringBuilder();
                if (string.IsNullOrWhiteSpace(txtProjectName.Text)) //this function checks for both null or empty string.
                {
                    sbMessage.Append("*Project Name can not be empty." + Environment.NewLine);
                }
                if (string.IsNullOrWhiteSpace(txtProductName.Text)) //this function checks for both null or empty string.
                {
                    sbMessage.Append("*Product Name can not be empty." + Environment.NewLine);
                }
                if (string.IsNullOrWhiteSpace(txtCreator.Text)) //this function checks for both null or empty string.
                {
                    sbMessage.Append("*Creator can not be empty." + Environment.NewLine);
                }
                if (sbMessage.Length != 0)
                {
                    MessageBox.Show(sbMessage.ToString(), "Error Message");
                }
                else
                {
                    // Declare & Set MetricsSuiteMain Class
                    MetricsSuiteMain msmProject = new MetricsSuiteMain
                    {
                        ProjectName = txtProjectName.Text,
                        ProductName = txtProductName.Text,
                        Creator = txtCreator.Text,
                        Comments = txtComments.Text
                    };

                    if (frmMetricsSuite.metricsSuiteMain == null)
                        frmMetricsSuite.metricsSuiteMain = msmProject;
                    else
                    {
                        frmMetricsSuite.metricsSuiteMain = msmProject;
                        
                        foreach(Control c in mainForm.Controls)
                        {
                            if (c is TabControl)
                            {
                                TabControl tc = (TabControl)c;
                                for (int i = tc.TabPages.Count-1; i >= 0; i--)
                                    tc.TabPages[i].Dispose();
                            }
                        }
                        mainForm.Update();
                    }

                    mainForm.Text = "CECS 543 Metrics Suite" + " - " + txtProjectName.Text;
                    
                    this.Close();

                    Control[] controls = mainForm.Controls.Find("msMenu", true);
                    foreach (Control ctrl in controls)
                    {
                        if (ctrl.Name == "msMenu")
                        {
                            MenuStrip strip = ctrl as MenuStrip;
                            strip.Items["msEdit"].Enabled = true;
                            strip.Items["msPreference"].Enabled = true;
                            strip.Items["msMetrics"].Enabled = true;
                            strip.Items["msProjectCode"].Enabled = true;
                        }
                    }

                    controls = mainForm.Controls.Find("tvFile", true);
                    foreach (Control ctrl in controls)
                    {
                        if (ctrl.Name == "tvFile")
                        {
                            TreeView tvFile = ctrl as TreeView;
                            tvFile.Visible = true;
                            tvFile.Nodes.Clear();

                            TreeNode root = new TreeNode(txtProjectName.Text);
                            //root.Nodes.Add()
                            tvFile.Nodes.Add(root);
                            tvFile.Update();
                        }
                    }

                    frmMetricsSuite._isDirty = true;
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occurred!", "Error Message");
            }
        }
    }
}
