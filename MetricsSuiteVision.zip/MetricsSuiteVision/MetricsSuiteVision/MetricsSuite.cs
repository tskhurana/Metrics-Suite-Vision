﻿using Antlr.Runtime;
using Antlr.Runtime.Tree;
using Microsoft.VisualBasic;
using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace MetricsSuiteVision
{
    public partial class frmMetricsSuite : Form
    {
        // Static Main Class Objects
        public static MetricsSuiteMain metricsSuiteMain;
        public static string sSelectedLanguage;
        public static bool _isDirty = false;

        public frmMetricsSuite()
        {
            InitializeComponent();
            if (metricsSuiteMain == null)
            {
                msEdit.Enabled = false;
                msPreference.Enabled = false;
                msMetrics.Enabled = false;
                msProjectCode.Enabled = false;
                miProjectCodeStatistics.Enabled = false;
            }
            else
            {
                msEdit.Enabled = true;
                msPreference.Enabled = true;
                msMetrics.Enabled = true;
                msProjectCode.Enabled = true;
            }
            
            //this.tcFunctionPoints.DrawItem += tcFunctionPoints_DrawItem;
        }
                

        private void miFPData_Click(object sender, EventArgs e)
        {
            try
            {
                string sFunctionPointName = Interaction.InputBox("Please enter name for Function Point", "Function Point Name", "FunctionPoint" + tcFunctionPoints.TabCount);
                if (sFunctionPointName.Length > 0)
                {
                    // Initialize Function Point class
                    FunctionPoint functionPoint = new FunctionPoint();
                    functionPoint.Name = sFunctionPointName;
                    functionPoint.TabIndex = tcFunctionPoints.TabIndex;
                    frmMetricsSuite.metricsSuiteMain.FunctionPoint.Add(functionPoint);

                    tcFunctionPoints.Visible = true;
                    //tcFunctionPoints.Dock = DockStyle.Left;
                    tcFunctionPoints.Alignment = TabAlignment.Top;

                    // Creating TabPage
                    TabPage tabPage1 = new TabPage
                    {
                        Text = sFunctionPointName
                    };

                    // Initializing & Adding Function Point User Control to TabPage
                    FunctionPoints functionPoints = new FunctionPoints(this);
                    tabPage1.Controls.Add(functionPoints);

                    // Adding TabPage to TabControl
                    tcFunctionPoints.TabPages.Add(tabPage1);

                    tcFunctionPoints.SelectedTab = tabPage1;

                    functionPoints.tabIndex = tcFunctionPoints.TabCount - 1;

                    // Updating TabControl to add new TabPage
                    tcFunctionPoints.Update();

                    tvFile.Nodes[0].Nodes.Add(sFunctionPointName);
                    tvFile.ExpandAll();
                    tvFile.Update();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occurred!", "Error Message");
            }
        }

        private void miNew_Click(object sender, EventArgs e)
        {
            try
            {
                if (_isDirty == true)
                {
                    var confirmResult = MessageBox.Show("Would you like to save current project before creating a new project?", "Save Comfirmation!!"
                        , MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    if (confirmResult == DialogResult.No)
                    {
                        _isDirty = false;
                    }
                    else if (confirmResult == DialogResult.Yes)
                    {
                        SaveProject();
                    }
                    else
                    {
                        throw new Exception();
                    }
                }

                NewProject newProject = new NewProject(this);
                newProject.ShowDialog();
            }
            catch (Exception)
            {
                // Do Nothing
            }
        }

        private void miExit_Click(object sender, EventArgs e)
        {
            if (_isDirty == true)
            {
                var confirmResult = MessageBox.Show("Would you like to save project before closing?", "Save Comfirmation!!"
                    , MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (confirmResult == DialogResult.No)
                {
                    _isDirty = false;
                    this.Close();
                }
                else if (confirmResult == DialogResult.Yes)
                {
                    SaveProject();
                }
                else
                {
                    // Do Nothing
                }
            }
            else
                this.Close();
        }

        private void miOpen_Click(object sender, EventArgs e)
        {
            try
            {
                if (_isDirty == true)
                {
                    var confirmResult = MessageBox.Show("Would you like to save project before opening another?", "Save Comfirmation!!"
                        , MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    if (confirmResult == DialogResult.No)
                    {
                        _isDirty = false;
                    }
                    else if (confirmResult == DialogResult.Yes)
                    {
                        SaveProject();
                        for (int i = tcFunctionPoints.TabPages.Count - 1; i >= 0; i--)
                            tcFunctionPoints.TabPages[i].Dispose();
                    }
                    else
                    {
                        throw new Exception();
                    }
                }

                OpenFileDialog fileDialog = new OpenFileDialog();
                fileDialog.Filter = "MetricsSuite|*.ms";
                fileDialog.Title = "Open a MetricsSuite Project";
                fileDialog.RestoreDirectory = true;
                fileDialog.ShowDialog();
                if (fileDialog.FileName.Contains(".ms"))
                {
                    for (int i = tcFunctionPoints.TabPages.Count - 1; i >= 0; i--)
                        tcFunctionPoints.TabPages[i].Dispose();

                    XmlSerializer xs = new XmlSerializer(typeof(MetricsSuiteMain));

                    try
                    {
                        using (var sr = new StreamReader(fileDialog.FileName))
                        {
                            metricsSuiteMain = (MetricsSuiteMain)xs.Deserialize(sr);
                        }
                    }
                    catch (Exception ex)
                    {
                        if (ex.HResult == 2147024864)
                            MessageBox.Show("Program cannot access the file as it is being used by anothoer program.", "Access Denied");
                        throw new Exception();
                    }

                    if (metricsSuiteMain != null)
                    {
                        this.Text = "CECS 543 Metrics Suite" + " - " + metricsSuiteMain.ProjectName.ToString();

                        LoadProjectTree();

                        if (metricsSuiteMain.FunctionPoint.Count > 0)
                        {
                            AddFunctionPointTab();
                        }
                        if (metricsSuiteMain.ObjSMI != null)
                        {
                            AddSMITab();
                        }
                        if (metricsSuiteMain.JavaFiles.Count > 0)
                        {
                            //foreach (JavaFile jf in metricsSuiteMain.JavaFiles)
                            AddJavaTab();
                        }

                        msEdit.Enabled = true;
                        msPreference.Enabled = true;
                        msMetrics.Enabled = true;
                        msProjectCode.Enabled = true;

                        _isDirty = true;
                    }
                }
            }
            catch (Exception ex)
            {
                // Do Nothing
            }
        }

        private void LoadProjectTree()
        {
            tvFile.Visible = true;
            tvFile.Nodes.Clear();

            TreeNode root = new TreeNode(metricsSuiteMain.ProjectName);
            //root.Nodes.Add()
            tvFile.Nodes.Add(root);

            for (int i = 0; i < metricsSuiteMain.FunctionPoint.Count; i++)
            {
                TreeNode childNode = new TreeNode(metricsSuiteMain.FunctionPoint[i].Name);
                tvFile.Nodes[0].Nodes.Add(childNode);
            }
            for (int i = 0; i < metricsSuiteMain.JavaFiles.Count; i++)
            {
                TreeNode childNode = new TreeNode(metricsSuiteMain.JavaFiles[i].FileName);
                tvFile.Nodes[0].Nodes.Add(childNode);
            }
            if (metricsSuiteMain.ObjSMI != null)
            {
                TreeNode childNode = new TreeNode("SMI");
                tvFile.Nodes[0].Nodes.Add(childNode);
            }
            tvFile.Update();
        }

        private void AddFunctionPointTab()
        {
            tcFunctionPoints.Visible = true;
            //tcFunctionPoints.Dock = DockStyle.Left;
            tcFunctionPoints.Alignment = TabAlignment.Top;

            for (int i = 0; i < metricsSuiteMain.FunctionPoint.Count; i++)
            {
                if (!metricsSuiteMain.FunctionPoint[i].IsClosed)
                {
                    // Creating TabPage
                    TabPage tabPage1 = new TabPage
                    {
                        Text = metricsSuiteMain.FunctionPoint[i].Name
                    };

                    // Adding User Control to TabPage
                    FunctionPoints functionPoints = new FunctionPoints(this, i);
                    tabPage1.Controls.Add(functionPoints);

                    // Adding TabPage to TabControl
                    tcFunctionPoints.TabPages.Add(tabPage1);

                    tcFunctionPoints.SelectedTab = tabPage1;

                    functionPoints.tabIndex = tcFunctionPoints.TabCount - 1;

                    // Updating TabControl to add new TabPage
                    tcFunctionPoints.Update();

                    bool bShouldAddNode = true;

                    foreach (TreeNode tn in tvFile.Nodes[0].Nodes)
                    {
                        if (tn.Text == metricsSuiteMain.FunctionPoint[i].Name)
                        {
                            bShouldAddNode = false;
                        }
                    }

                    if (bShouldAddNode)
                    {
                        tvFile.Nodes[0].Nodes.Add(metricsSuiteMain.FunctionPoint[i].Name);
                        tvFile.ExpandAll();
                        tvFile.Update();
                    }
                }
            }
        }

        private void miSave_Click(object sender, EventArgs e)
        {
            SaveProject();
            _isDirty = false;
        }

        private void SaveProject()
        {
            SaveFileDialog fileDialog = new SaveFileDialog();
            fileDialog.Filter = "MetricsSuite|*.ms";
            fileDialog.Title = "Save a MetricsSuite Project";
            fileDialog.RestoreDirectory = true;

            if (fileDialog.ShowDialog() == DialogResult.OK && fileDialog.FileName != "")
            {
                XmlSerializer xs = new XmlSerializer(typeof(MetricsSuiteMain));
                TextWriter tw = new StreamWriter(fileDialog.FileName);
                xs.Serialize(tw, metricsSuiteMain);
            }
        }

        private void miLanguage_Click(object sender, EventArgs e)
        {
            LanguageSelection languageSelection = new LanguageSelection(this);
            languageSelection.ShowDialog();
        }

        private void AddSMITab()
        {
            tcFunctionPoints.Visible = true;
            //tcFunctionPoints.Dock = DockStyle.Left;
            tcFunctionPoints.Alignment = TabAlignment.Top;

            if (!metricsSuiteMain.ObjSMI.IsClosed)
            {
                // Creating TabPage
                TabPage tabPage1 = new TabPage
                {
                    Text = "SMI"
                };

                SMI objSMI = new SMI(metricsSuiteMain.ObjSMI);
                tabPage1.Controls.Add(objSMI);

                // Adding TabPage to TabControl
                tcFunctionPoints.TabPages.Add(tabPage1);

                tcFunctionPoints.SelectedTab = tabPage1;

                objSMI.tabIndex = tcFunctionPoints.TabCount - 1;
                metricsSuiteMain.ObjSMI.IsClosed = false;
                
                // Updating TabControl to add new TabPage
                tcFunctionPoints.Update();

                bool bShouldAddNode = true;

                foreach (TreeNode tn in tvFile.Nodes[0].Nodes)
                {
                    if (tn.Text == "SMI")
                    {
                        bShouldAddNode = false;
                    }
                }

                if (bShouldAddNode)
                {
                    tvFile.Nodes[0].Nodes.Add("SMI");
                    tvFile.ExpandAll();
                    tvFile.Update();
                }
            }
        }

        private void frmMetricsSuite_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_isDirty == true)
            {
                var confirmResult = MessageBox.Show("Would you like to save project before closing?", "Save Comfirmation!!"
                    , MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (confirmResult == DialogResult.No)
                {
                    _isDirty = false;
                }
                else if (confirmResult == DialogResult.Yes)
                {
                    SaveProject();
                }
                else
                {
                    e.Cancel = true;
                }
            }
        }

        private void miSMI_Click(object sender, EventArgs e)
        {
            if (metricsSuiteMain.ObjSMI == null)
            {
                SMITable objSMITable = new SMITable();
                metricsSuiteMain.ObjSMI = objSMITable;

                tcFunctionPoints.Visible = true;
                //tcFunctionPoints.Dock = DockStyle.Left;
                tcFunctionPoints.Alignment = TabAlignment.Top;

                // Creating TabPage
                TabPage tabPage1 = new TabPage
                {
                    Text = "SMI"
                };

                SMI objSMI = new SMI();

                tabPage1.Controls.Add(objSMI);

                // Adding TabPage to TabControl
                tcFunctionPoints.TabPages.Add(tabPage1);

                tcFunctionPoints.SelectedTab = tabPage1;

                objSMI.TabIndex = tcFunctionPoints.TabCount - 1;
                metricsSuiteMain.ObjSMI.IsClosed = false;

                // Updating TabControl to add new TabPage
                tcFunctionPoints.Update();

                tvFile.Nodes[0].Nodes.Add("SMI");
                tvFile.ExpandAll();
                tvFile.Update();
            }
            else
                MessageBox.Show("You are not allowed to open multiple SMI!!!", "Error Message");
        }

        private void miAddCode_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Filter = "Java Files|*.java";
            fileDialog.RestoreDirectory = true;
            fileDialog.Multiselect = true;
            fileDialog.Title = "Select Java File(s)";
            fileDialog.ShowDialog();

            StringBuilder sbError = new StringBuilder();

            foreach (String file in fileDialog.FileNames)
            {
                JavaFile javaFile = new JavaFile();
                javaFile.FileName = Path.GetFileName(file);
                javaFile.FilePath = Path.GetDirectoryName(file);
                javaFile.IsOpened = false;

                bool bIsPresent = false;    // Used to check if same file if added multiple times

                foreach (JavaFile jf in metricsSuiteMain.JavaFiles)
                {
                    if (jf.FileName == javaFile.FileName)
                    {
                        bIsPresent = true;
                        sbError.Append(javaFile.FileName + Environment.NewLine);
                    }
                }

                if (!bIsPresent)
                {
                    metricsSuiteMain.JavaFiles.Add(javaFile);
                    miProjectCodeStatistics.Enabled = true;
                    _isDirty = true;
                }
            }

            if (sbError.Length != 0)
                MessageBox.Show("Following File(s) as already present in the project" + Environment.NewLine + sbError);
        }

        private void miProjectCodeStatistics_Click(object sender, EventArgs e)
        {
            AddJavaTab();
            miProjectCodeStatistics.Enabled = false;
            _isDirty = true;
        }

        private StringBuilder JavaCodeStatistics(JavaFile jf)
        {
            StringBuilder sbFileStats = new StringBuilder();

            using (StreamReader fileStream = new StreamReader(jf.FilePath + "\\" + jf.FileName))
            {
                byte[] byteArray = Encoding.UTF8.GetBytes(fileStream.ReadToEnd());
                MemoryStream stream = new MemoryStream(byteArray);

                ANTLRInputStream inputStream = new ANTLRInputStream(stream);
                JavaJavaLexer lexer = new JavaJavaLexer(inputStream);
                CommonTokenStream commonTokenStream = new CommonTokenStream(lexer);
                JavaJavaParser parser = new JavaJavaParser(commonTokenStream);
                parser.compilationUnit();
                
                int iOperator = JavaMetrics.UniqueSpecial.Count + JavaMetrics.UniqueKeywords.Count;
                int iOperand = JavaMetrics.UniqueConstants.Count + JavaMetrics.UniqueIdentifiers.Count;
                int iTotalOperators = parser.specialcount + parser.keywordCount;
                int iTotalOperands = lexer.constantcount + parser.identcount;
                int iVocabulary = iOperand + iOperator;
                int iProgramLength = iTotalOperands + iTotalOperators;
                double dVolume = iProgramLength + Math.Log(iVocabulary) / Math.Log(2);
                double dDifficulty = (iOperator * iTotalOperands) / (2 * iOperand);
                double dEfforts = dDifficulty * dVolume;
                double dTime = dEfforts / 18;//in seconds
                double dBug = dTime / 3000;
                
                FileInfo f = new FileInfo(jf.FilePath + "\\" + jf.FileName);

                sbFileStats.Append("File name: " + jf.FileName + Environment.NewLine);
                sbFileStats.Append("File length in bytes: " + f.Length + Environment.NewLine);
                sbFileStats.Append("File white space: " + lexer.ws + Environment.NewLine);
                sbFileStats.Append("File comment space in bytes: " + lexer.commentcount + Environment.NewLine);
                sbFileStats.Append("Comment percentage of file: " + (((double)lexer.commentcount / (double)f.Length) * 100).ToString() + Environment.NewLine);
                sbFileStats.Append("Halstead metrics: " + Environment.NewLine);
                sbFileStats.Append("\tUnique operators: " + iOperator + Environment.NewLine);
                sbFileStats.Append("\tUnique operands: " + iOperand + Environment.NewLine);
                sbFileStats.Append("\tTotal operators: " + iTotalOperators + Environment.NewLine);
                sbFileStats.Append("\tTotal operands: " + iTotalOperands + Environment.NewLine);
                sbFileStats.Append("\tProgram length (N) = " + iProgramLength + Environment.NewLine);
                sbFileStats.Append("\tProgram vocabulary (n) = " + iVocabulary + Environment.NewLine);
                sbFileStats.Append("\tVolume = " + dVolume + Environment.NewLine);
                sbFileStats.Append("\tDifficulty = " + dDifficulty + Environment.NewLine);
                sbFileStats.Append("\tEffort = " + dEfforts + Environment.NewLine);
                sbFileStats.Append("\tTime = " + String.Format("{0:n}", dTime) + " (" + String.Format("{0:n}", dTime / 60) + " minutes or " + String.Format("{0:n}", dTime / 3600) + " hours or " + String.Format("{0:n}", dTime / 504000) + " person months)" + Environment.NewLine);
                sbFileStats.Append("\tBugs expected = " + dBug + Environment.NewLine);

                //No of Classes in a Java File
                //int iClassCount = 0;
                //foreach (String s in ) { if (s == "class") iClassCount++; }
                sbFileStats.Append("\tClass Count = " + JavaMetrics.ClassDetailsObj.Count + Environment.NewLine);

                sbFileStats.Append("\nMcCabe's Cyclomatic Complexity: ");

                foreach (string str in JavaMetrics.MccabeValues)
                {
                    sbFileStats.Append("\n\t" + str);
                }
            }

            return sbFileStats;
        }

        private void AddJavaTab()
        {
            foreach (JavaFile jf in metricsSuiteMain.JavaFiles)
            {
                if (!jf.IsOpened)
                {
                    StringBuilder sbFileStats = JavaCodeStatistics(jf);

                    tcFunctionPoints.Visible = true;
                    tcFunctionPoints.Alignment = TabAlignment.Top;

                    // Creating TabPage
                    TabPage tabPage1 = new TabPage
                    {
                        Text = jf.FileName
                    };

                    RichTextBox richTextBox = new RichTextBox();
                    richTextBox.Text = sbFileStats.ToString();
                    richTextBox.Height = tcFunctionPoints.Height;
                    richTextBox.Width = tcFunctionPoints.Width;
                    richTextBox.ScrollBars = RichTextBoxScrollBars.ForcedVertical;
                    tabPage1.Controls.Add(richTextBox);

                    // Adding TabPage to TabControl
                    tcFunctionPoints.TabPages.Add(tabPage1);

                    tcFunctionPoints.SelectedTab = tabPage1;

                    jf.TabIndex = tcFunctionPoints.TabCount - 1;
                    jf.IsOpened = true;

                    // Updating TabControl to add new TabPage
                    tcFunctionPoints.Update();

                    bool bShouldAddNode = true;

                    foreach (TreeNode tn in tvFile.Nodes[0].Nodes)
                    {
                        if (tn.Text == jf.FileName)
                        {
                            bShouldAddNode = false;
                        }
                    }

                    if (bShouldAddNode)
                    {
                        tvFile.Nodes[0].Nodes.Add(jf.FileName);
                        tvFile.ExpandAll();
                        tvFile.Update();
                    }
                }
            }
        }

        private void tsmOpen_Click(object sender, EventArgs e)
        {
            contextMenuOperation(0);
        }

        private void tsmClose_Click(object sender, EventArgs e)
        {
            contextMenuOperation(1);
        }

        private void tsmDelete_Click(object sender, EventArgs e)
        {
            contextMenuOperation(2);
            tvFile.SelectedNode.Remove();
            tvFile.Update();
        }

        private void contextMenuOperation(int iOperation)
        {
            string sFileName = tvFile.SelectedNode.Text;

            if (iOperation == 0)//Open Specific Tab
            {
                if (sFileName.Contains("SMI"))
                {
                    if (metricsSuiteMain.ObjSMI.IsClosed)
                    {
                        // Creating TabPage
                        TabPage tabPage1 = new TabPage
                        {
                            Text = "SMI"
                        };

                        SMI objSMI = new SMI(metricsSuiteMain.ObjSMI);
                        tabPage1.Controls.Add(objSMI);

                        // Adding TabPage to TabControl
                        tcFunctionPoints.TabPages.Add(tabPage1);

                        tcFunctionPoints.SelectedTab = tabPage1;

                        objSMI.tabIndex = tcFunctionPoints.TabCount - 1;
                        metricsSuiteMain.ObjSMI.IsClosed = false;

                        // Updating TabControl to add new TabPage
                        tcFunctionPoints.Update();

                    }
                }
                else if (sFileName.Contains(".java"))
                {
                    JavaFile jfFile = null;

                    foreach (JavaFile jf in metricsSuiteMain.JavaFiles)
                    {
                        if (jf.FileName == sFileName)
                            jfFile = jf;
                    }

                    if (jfFile != null)
                    {
                        if (!jfFile.IsOpened)
                        {
                            StringBuilder sbFileStats = JavaCodeStatistics(jfFile);

                            tcFunctionPoints.Visible = true;
                            tcFunctionPoints.Alignment = TabAlignment.Top;

                            // Creating TabPage
                            TabPage tabPage1 = new TabPage
                            {
                                Text = jfFile.FileName
                            };

                            RichTextBox richTextBox = new RichTextBox();
                            richTextBox.Text = sbFileStats.ToString();
                            richTextBox.Height = tcFunctionPoints.Height;
                            richTextBox.Width = tcFunctionPoints.Width;
                            richTextBox.ScrollBars = RichTextBoxScrollBars.ForcedVertical;
                            tabPage1.Controls.Add(richTextBox);

                            // Adding TabPage to TabControl
                            tcFunctionPoints.TabPages.Add(tabPage1);

                            tcFunctionPoints.SelectedTab = tabPage1;

                            jfFile.TabIndex = tcFunctionPoints.TabCount - 1;
                            jfFile.IsOpened = true;

                            // Updating TabControl to add new TabPage
                            tcFunctionPoints.Update();
                        }
                    }
                }
                else
                {
                    int iFunctionPointTabIndex = -1;
                    for (int i = 0; i < metricsSuiteMain.FunctionPoint.Count; i++)
                    {
                        if (metricsSuiteMain.FunctionPoint[i].Name == sFileName)
                            iFunctionPointTabIndex = i;
                    }
                    //int iFunctionPointTabIndex = Convert.ToInt32(sFileName.Substring(sFileName.IndexOf('-') + 1));
                    if (iFunctionPointTabIndex != -1)
                    {
                        if (metricsSuiteMain.FunctionPoint[iFunctionPointTabIndex].IsClosed)
                        {
                            // Creating TabPage
                            TabPage tabPage1 = new TabPage
                            {
                                Text = metricsSuiteMain.FunctionPoint[iFunctionPointTabIndex].Name
                            };

                            // Adding User Control to TabPage
                            FunctionPoints functionPoints = new FunctionPoints(this, iFunctionPointTabIndex);
                            tabPage1.Controls.Add(functionPoints);

                            // Adding TabPage to TabControl
                            tcFunctionPoints.TabPages.Add(tabPage1);

                            tcFunctionPoints.SelectedTab = tabPage1;

                            functionPoints.tabIndex = tcFunctionPoints.TabCount - 1;

                            // Updating TabControl to add new TabPage
                            tcFunctionPoints.Update();
                        }
                    }
                }

            }
            else if (iOperation == 1) //Close a specific Tab
            {
                if (sFileName.Contains("SMI"))
                {
                    foreach (TabPage tp in tcFunctionPoints.TabPages)
                    {
                        if (tp.Text == "SMI")
                        {
                            tp.Dispose();
                            tcFunctionPoints.Update();
                            metricsSuiteMain.ObjSMI.IsClosed = true;

                            break;
                        }
                    }
                }
                else if (sFileName.Contains(".java"))
                {
                    foreach (TabPage tp in tcFunctionPoints.TabPages)
                    {
                        if (tp.Text == sFileName)
                        {
                            tp.Dispose();
                            tcFunctionPoints.Update();

                            foreach (JavaFile jf in metricsSuiteMain.JavaFiles)
                            {
                                if (jf.FileName == sFileName)
                                    jf.IsOpened = false;
                            }

                            break;
                        }

                        
                    }
                }
                else
                {
                    foreach (TabPage tp in tcFunctionPoints.TabPages)
                    {
                        if (tp.Text == sFileName)
                        {
                            tp.Dispose();
                            tcFunctionPoints.Update();

                            for (int i = 0; i < metricsSuiteMain.FunctionPoint.Count; i++)
                            {
                                if (metricsSuiteMain.FunctionPoint[i].Name == sFileName)
                                    metricsSuiteMain.FunctionPoint[i].IsClosed = true;
                            }

                            break;
                        }
                    }
                }

                //tcFunctionPoints.TabPages[sFileName].Dispose();
                //tcFunctionPoints.Update();

            }
            else if (iOperation == 2)
            {
                var confirmResult = MessageBox.Show("Delete " + sFileName, "Select an option"
                        , MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (confirmResult == DialogResult.Yes)
                {
                    if (sFileName.Contains("SMI"))
                    {
                        //tcFunctionPoints.TabPages["SMI"].Dispose();
                        foreach (TabPage tp in tcFunctionPoints.TabPages)
                        {
                            if (tp.Text == "SMI")
                            {
                                tp.Dispose();
                                tcFunctionPoints.Update();
                                metricsSuiteMain.ObjSMI = null;
                            }
                        }
                    }
                    else if (sFileName.Contains(".java"))
                    {
                        foreach (TabPage tp in tcFunctionPoints.TabPages)
                        {
                            if (tp.Text == sFileName)
                            {
                                tp.Dispose();
                                tcFunctionPoints.Update();                                
                            }
                        }

                        for (int i = 0; i < metricsSuiteMain.JavaFiles.Count; i++)
                        {
                            if (metricsSuiteMain.JavaFiles[i].FileName == sFileName)
                                metricsSuiteMain.JavaFiles.RemoveAt(i);
                        }
                    }
                    else
                    {
                        //int iFunctionPointTabIndex = -1;
                        for (int i = 0; i < metricsSuiteMain.FunctionPoint.Count; i++)
                        {
                            if (metricsSuiteMain.FunctionPoint[i].Name == sFileName)
                                metricsSuiteMain.FunctionPoint.RemoveAt(i);
                        }
                        //int iFunctionPointTabIndex = Convert.ToInt32(sFileName.Substring(sFileName.IndexOf('-') + 1));

                        //    tcFunctionPoints.TabPages[sFileName].Dispose();
                        //    //int iFunctionPointTabIndex = Convert.ToInt32(sFileName.Substring(sFileName.IndexOf('-')));

                        foreach (TabPage tp in tcFunctionPoints.TabPages)
                        {
                            if (tp.Text == sFileName)
                            {
                                tp.Dispose();
                                tcFunctionPoints.Update();
                            }
                        }
                    }
                }
            }
        }

        private void tvFile_MouseUp(object sender, MouseEventArgs e)
        {
            // Show menu only if the right mouse button is clicked.
            if (e.Button == MouseButtons.Right)
            { // Point where the mouse is clicked.
                Point p = new Point(e.X, e.Y);

                // Get the node that the user has clicked.
                TreeNode node = tvFile.GetNodeAt(p);
                if (node != null && tvFile.Nodes[0] != node)
                {
                    cmsFileMenu.Show(System.Windows.Forms.Cursor.Position);
                }
            }

        }
    }
}
