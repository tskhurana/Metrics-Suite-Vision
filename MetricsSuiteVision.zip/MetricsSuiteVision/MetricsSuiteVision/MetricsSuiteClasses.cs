﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetricsSuiteVision
{
    public class MetricsSuiteMain
    {
        private string projectName;
        private string productName;
        private string creator;
        private string comments;

        private List<FunctionPoint> functionPoint = new List<MetricsSuiteVision.FunctionPoint>();
        private SMITable objSMI;
        private List<JavaFile> javaFiles = new List<JavaFile>();

        #region Getter Setter
        public string ProjectName { get => projectName; set => projectName = value; }
        public string ProductName { get => productName; set => productName = value; }
        public string Creator { get => creator; set => creator = value; }
        public string Comments { get => comments; set => comments = value; }
        public List<FunctionPoint> FunctionPoint { get => functionPoint; set => functionPoint = value; }
        public SMITable ObjSMI { get => objSMI; set => objSMI = value; }
        public List<JavaFile> JavaFiles { get => javaFiles; set => javaFiles = value; }
        #endregion

    }        
    public class FunctionPoint
    {
        private string name = "Function Point";
        private string selectedLanguage = "None";
        private int tabIndex;
        private bool _isClosed = false;
        private int exernalInputs;
        private int exernalInputComplexity = 4;
        private int externalOutputs;
        private int externalOutputComplexity = 5;
        private int externalInquiries;
        private int externalInquirieComplexity = 4;
        private int internalLogicalFiles;
        private int internalLogicalFileComplexity = 10;
        private int externalInterfaceFiles;
        private int externalInterfaceFileComplexity = 7;
        private int totalCount;
        private double fpCount;
        private int valueAdjustments;
        private long estimatedCodeSize;

        private int vaf1;
        private int vaf2;
        private int vaf3;
        private int vaf4;
        private int vaf5;
        private int vaf6;
        private int vaf7;
        private int vaf8;
        private int vaf9;
        private int vaf10;
        private int vaf11;
        private int vaf12;
        private int vaf13;
        private int vaf14;

        #region Getter Setter
        public string Name { get => name; set => name = value; }
        public string SelectedLanguage { get => selectedLanguage; set => selectedLanguage = value; }
        public int TabIndex { get => tabIndex; set => tabIndex = value; }
        public bool IsClosed { get => _isClosed; set => _isClosed = value; }
        public int ExernalInputs { get => exernalInputs; set => exernalInputs = value; }
        public int ExernalInputComplexity { get => exernalInputComplexity; set => exernalInputComplexity = value; }
        public int ExternalOutputs { get => externalOutputs; set => externalOutputs = value; }
        public int ExternalOutputComplexity { get => externalOutputComplexity; set => externalOutputComplexity = value; }
        public int ExternalInquiries { get => externalInquiries; set => externalInquiries = value; }
        public int ExternalInquirieComplexity { get => externalInquirieComplexity; set => externalInquirieComplexity = value; }
        public int InternalLogicalFiles { get => internalLogicalFiles; set => internalLogicalFiles = value; }
        public int InternalLogicalFileComplexity { get => internalLogicalFileComplexity; set => internalLogicalFileComplexity = value; }
        public int ExternalInterfaceFiles { get => externalInterfaceFiles; set => externalInterfaceFiles = value; }
        public int ExternalInterfaceFileComplexity { get => externalInterfaceFileComplexity; set => externalInterfaceFileComplexity = value; }
        public int TotalCount { get => totalCount; set => totalCount = value; }
        public double FpCount { get => fpCount; set => fpCount = value; }
        public int ValueAdjustments { get => valueAdjustments; set => valueAdjustments = value; }
        public long EstimatedCodeSize { get => estimatedCodeSize; set => estimatedCodeSize = value; }

        public int Vaf1 { get => vaf1; set => vaf1 = value; }
        public int Vaf2 { get => vaf2; set => vaf2 = value; }
        public int Vaf3 { get => vaf3; set => vaf3 = value; }
        public int Vaf4 { get => vaf4; set => vaf4 = value; }
        public int Vaf5 { get => vaf5; set => vaf5 = value; }
        public int Vaf6 { get => vaf6; set => vaf6 = value; }
        public int Vaf7 { get => vaf7; set => vaf7 = value; }
        public int Vaf8 { get => vaf8; set => vaf8 = value; }
        public int Vaf9 { get => vaf9; set => vaf9 = value; }
        public int Vaf10 { get => vaf10; set => vaf10 = value; }
        public int Vaf11 { get => vaf11; set => vaf11 = value; }
        public int Vaf12 { get => vaf12; set => vaf12 = value; }
        public int Vaf13 { get => vaf13; set => vaf13 = value; }
        public int Vaf14 { get => vaf14; set => vaf14 = value; }
        

        #endregion
    }
    public class SMITable
    {
        private List<SingleSMI> sSMI = new List<SingleSMI>();
        private bool _isClosed = false;
        private int tabIndex;

        #region Getter Setter
        public List<SingleSMI> SSMI { get => sSMI; set => sSMI = value; }
        public bool IsClosed { get => _isClosed; set => _isClosed = value; }
        public int TabIndex { get => tabIndex; set => tabIndex = value; }
        #endregion
    }
    public class SingleSMI
    {
        private double dSMI;
        private double dAdded;
        private double dChanged;
        private double dDeleted;
        private double dTotal;

        #region Getter Setter
        public double DSMI { get => dSMI; set => dSMI = value; }
        public double DAdded { get => dAdded; set => dAdded = value; }
        public double DChanged { get => dChanged; set => dChanged = value; }
        public double DDeleted { get => dDeleted; set => dDeleted = value; }
        public double DTotal { get => dTotal; set => dTotal = value; }
        #endregion
    }
    public class JavaFile
    {
        private string fileName;
        private string filePath;
        private bool isOpened;
        private int tabIndex;

        #region Getter Setter
        public string FileName { get => fileName; set => fileName = value; }
        public string FilePath { get => filePath; set => filePath = value; }
        public bool IsOpened { get => isOpened; set => isOpened = value; }
        public int TabIndex { get => tabIndex; set => tabIndex = value; }
        #endregion
    }
}
