﻿namespace MetricsSuiteVision
{
    partial class LanguageSelection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbLanguage = new System.Windows.Forms.Label();
            this.gbLanguage = new System.Windows.Forms.GroupBox();
            this.rbJava = new System.Windows.Forms.RadioButton();
            this.rbJavaScript = new System.Windows.Forms.RadioButton();
            this.rbVBScript = new System.Windows.Forms.RadioButton();
            this.rbVisualBasic = new System.Windows.Forms.RadioButton();
            this.rbCSharp = new System.Windows.Forms.RadioButton();
            this.rbCOBOL = new System.Windows.Forms.RadioButton();
            this.rbFortran = new System.Windows.Forms.RadioButton();
            this.rbHTML = new System.Windows.Forms.RadioButton();
            this.rbCPP = new System.Windows.Forms.RadioButton();
            this.rbC = new System.Windows.Forms.RadioButton();
            this.rbADA95 = new System.Windows.Forms.RadioButton();
            this.rbAssembler = new System.Windows.Forms.RadioButton();
            this.btnDone = new System.Windows.Forms.Button();
            this.gbLanguage.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbLanguage
            // 
            this.lbLanguage.AutoSize = true;
            this.lbLanguage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLanguage.Location = new System.Drawing.Point(21, 41);
            this.lbLanguage.Name = "lbLanguage";
            this.lbLanguage.Size = new System.Drawing.Size(279, 31);
            this.lbLanguage.TabIndex = 0;
            this.lbLanguage.Text = "Select one language";
            // 
            // gbLanguage
            // 
            this.gbLanguage.Controls.Add(this.rbJava);
            this.gbLanguage.Controls.Add(this.rbJavaScript);
            this.gbLanguage.Controls.Add(this.rbVBScript);
            this.gbLanguage.Controls.Add(this.rbVisualBasic);
            this.gbLanguage.Controls.Add(this.rbCSharp);
            this.gbLanguage.Controls.Add(this.rbCOBOL);
            this.gbLanguage.Controls.Add(this.rbFortran);
            this.gbLanguage.Controls.Add(this.rbHTML);
            this.gbLanguage.Controls.Add(this.rbCPP);
            this.gbLanguage.Controls.Add(this.rbC);
            this.gbLanguage.Controls.Add(this.rbADA95);
            this.gbLanguage.Controls.Add(this.rbAssembler);
            this.gbLanguage.Location = new System.Drawing.Point(26, 72);
            this.gbLanguage.Name = "gbLanguage";
            this.gbLanguage.Size = new System.Drawing.Size(313, 472);
            this.gbLanguage.TabIndex = 1;
            this.gbLanguage.TabStop = false;
            // 
            // rbJava
            // 
            this.rbJava.AutoSize = true;
            this.rbJava.Location = new System.Drawing.Point(30, 311);
            this.rbJava.Name = "rbJava";
            this.rbJava.Size = new System.Drawing.Size(89, 29);
            this.rbJava.TabIndex = 11;
            this.rbJava.TabStop = true;
            this.rbJava.Text = "Java";
            this.rbJava.UseVisualStyleBackColor = true;
            // 
            // rbJavaScript
            // 
            this.rbJavaScript.AutoSize = true;
            this.rbJavaScript.Location = new System.Drawing.Point(30, 346);
            this.rbJavaScript.Name = "rbJavaScript";
            this.rbJavaScript.Size = new System.Drawing.Size(144, 29);
            this.rbJavaScript.TabIndex = 10;
            this.rbJavaScript.TabStop = true;
            this.rbJavaScript.Text = "JavaScript";
            this.rbJavaScript.UseVisualStyleBackColor = true;
            // 
            // rbVBScript
            // 
            this.rbVBScript.AutoSize = true;
            this.rbVBScript.Location = new System.Drawing.Point(30, 381);
            this.rbVBScript.Name = "rbVBScript";
            this.rbVBScript.Size = new System.Drawing.Size(126, 29);
            this.rbVBScript.TabIndex = 9;
            this.rbVBScript.TabStop = true;
            this.rbVBScript.Text = "VBScript";
            this.rbVBScript.UseVisualStyleBackColor = true;
            // 
            // rbVisualBasic
            // 
            this.rbVisualBasic.AutoSize = true;
            this.rbVisualBasic.Location = new System.Drawing.Point(30, 416);
            this.rbVisualBasic.Name = "rbVisualBasic";
            this.rbVisualBasic.Size = new System.Drawing.Size(161, 29);
            this.rbVisualBasic.TabIndex = 8;
            this.rbVisualBasic.TabStop = true;
            this.rbVisualBasic.Text = "Visual Basic";
            this.rbVisualBasic.UseVisualStyleBackColor = true;
            // 
            // rbCSharp
            // 
            this.rbCSharp.AutoSize = true;
            this.rbCSharp.Location = new System.Drawing.Point(30, 171);
            this.rbCSharp.Name = "rbCSharp";
            this.rbCSharp.Size = new System.Drawing.Size(70, 29);
            this.rbCSharp.TabIndex = 7;
            this.rbCSharp.TabStop = true;
            this.rbCSharp.Text = "C#";
            this.rbCSharp.UseVisualStyleBackColor = true;
            // 
            // rbCOBOL
            // 
            this.rbCOBOL.AutoSize = true;
            this.rbCOBOL.Location = new System.Drawing.Point(30, 206);
            this.rbCOBOL.Name = "rbCOBOL";
            this.rbCOBOL.Size = new System.Drawing.Size(116, 29);
            this.rbCOBOL.TabIndex = 6;
            this.rbCOBOL.TabStop = true;
            this.rbCOBOL.Text = "COBOL";
            this.rbCOBOL.UseVisualStyleBackColor = true;
            // 
            // rbFortran
            // 
            this.rbFortran.AutoSize = true;
            this.rbFortran.Location = new System.Drawing.Point(30, 241);
            this.rbFortran.Name = "rbFortran";
            this.rbFortran.Size = new System.Drawing.Size(144, 29);
            this.rbFortran.TabIndex = 5;
            this.rbFortran.TabStop = true;
            this.rbFortran.Text = "FORTRAN";
            this.rbFortran.UseVisualStyleBackColor = true;
            // 
            // rbHTML
            // 
            this.rbHTML.AutoSize = true;
            this.rbHTML.Location = new System.Drawing.Point(30, 276);
            this.rbHTML.Name = "rbHTML";
            this.rbHTML.Size = new System.Drawing.Size(101, 29);
            this.rbHTML.TabIndex = 4;
            this.rbHTML.TabStop = true;
            this.rbHTML.Text = "HTML";
            this.rbHTML.UseVisualStyleBackColor = true;
            // 
            // rbCPP
            // 
            this.rbCPP.AutoSize = true;
            this.rbCPP.Location = new System.Drawing.Point(30, 136);
            this.rbCPP.Name = "rbCPP";
            this.rbCPP.Size = new System.Drawing.Size(82, 29);
            this.rbCPP.TabIndex = 3;
            this.rbCPP.TabStop = true;
            this.rbCPP.Text = "C++";
            this.rbCPP.UseVisualStyleBackColor = true;
            // 
            // rbC
            // 
            this.rbC.AutoSize = true;
            this.rbC.Location = new System.Drawing.Point(30, 101);
            this.rbC.Name = "rbC";
            this.rbC.Size = new System.Drawing.Size(58, 29);
            this.rbC.TabIndex = 2;
            this.rbC.TabStop = true;
            this.rbC.Text = "C";
            this.rbC.UseVisualStyleBackColor = true;
            // 
            // rbADA95
            // 
            this.rbADA95.AutoSize = true;
            this.rbADA95.Location = new System.Drawing.Point(30, 66);
            this.rbADA95.Name = "rbADA95";
            this.rbADA95.Size = new System.Drawing.Size(116, 29);
            this.rbADA95.TabIndex = 1;
            this.rbADA95.TabStop = true;
            this.rbADA95.Text = "ADA 95";
            this.rbADA95.UseVisualStyleBackColor = true;
            // 
            // rbAssembler
            // 
            this.rbAssembler.AutoSize = true;
            this.rbAssembler.Location = new System.Drawing.Point(30, 31);
            this.rbAssembler.Name = "rbAssembler";
            this.rbAssembler.Size = new System.Drawing.Size(144, 29);
            this.rbAssembler.TabIndex = 0;
            this.rbAssembler.TabStop = true;
            this.rbAssembler.Text = "Assembler";
            this.rbAssembler.UseVisualStyleBackColor = true;
            // 
            // btnDone
            // 
            this.btnDone.Location = new System.Drawing.Point(56, 569);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(139, 70);
            this.btnDone.TabIndex = 2;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = true;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // LanguageSelection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(384, 720);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.gbLanguage);
            this.Controls.Add(this.lbLanguage);
            this.Name = "LanguageSelection";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LanguageSelection";
            this.gbLanguage.ResumeLayout(false);
            this.gbLanguage.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbLanguage;
        private System.Windows.Forms.GroupBox gbLanguage;
        private System.Windows.Forms.RadioButton rbJava;
        private System.Windows.Forms.RadioButton rbJavaScript;
        private System.Windows.Forms.RadioButton rbVBScript;
        private System.Windows.Forms.RadioButton rbVisualBasic;
        private System.Windows.Forms.RadioButton rbCSharp;
        private System.Windows.Forms.RadioButton rbCOBOL;
        private System.Windows.Forms.RadioButton rbFortran;
        private System.Windows.Forms.RadioButton rbHTML;
        private System.Windows.Forms.RadioButton rbCPP;
        private System.Windows.Forms.RadioButton rbC;
        private System.Windows.Forms.RadioButton rbADA95;
        private System.Windows.Forms.RadioButton rbAssembler;
        private System.Windows.Forms.Button btnDone;
    }
}