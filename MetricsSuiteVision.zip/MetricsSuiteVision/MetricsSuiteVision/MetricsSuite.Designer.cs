﻿namespace MetricsSuiteVision
{
    partial class frmMetricsSuite
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.msMenu = new System.Windows.Forms.MenuStrip();
            this.msFile = new System.Windows.Forms.ToolStripMenuItem();
            this.miNew = new System.Windows.Forms.ToolStripMenuItem();
            this.miOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.miSave = new System.Windows.Forms.ToolStripMenuItem();
            this.miExit = new System.Windows.Forms.ToolStripMenuItem();
            this.msEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.msPreference = new System.Windows.Forms.ToolStripMenuItem();
            this.miLanguage = new System.Windows.Forms.ToolStripMenuItem();
            this.msMetrics = new System.Windows.Forms.ToolStripMenuItem();
            this.miFunctionPoints = new System.Windows.Forms.ToolStripMenuItem();
            this.miFPData = new System.Windows.Forms.ToolStripMenuItem();
            this.miSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.msProjectCode = new System.Windows.Forms.ToolStripMenuItem();
            this.miAddCode = new System.Windows.Forms.ToolStripMenuItem();
            this.miProjectCodeStatistics = new System.Windows.Forms.ToolStripMenuItem();
            this.msHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.tcFunctionPoints = new System.Windows.Forms.TabControl();
            this.tvFile = new System.Windows.Forms.TreeView();
            this.cmsFileMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmClose = new System.Windows.Forms.ToolStripMenuItem();
            this.tssFileMenu = new System.Windows.Forms.ToolStripSeparator();
            this.tsmDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.msMenu.SuspendLayout();
            this.cmsFileMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // msMenu
            // 
            this.msMenu.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.msMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.msFile,
            this.msEdit,
            this.msPreference,
            this.msMetrics,
            this.msProjectCode,
            this.msHelp});
            this.msMenu.Location = new System.Drawing.Point(0, 0);
            this.msMenu.Name = "msMenu";
            this.msMenu.Size = new System.Drawing.Size(1103, 40);
            this.msMenu.TabIndex = 0;
            this.msMenu.Text = "Menu";
            // 
            // msFile
            // 
            this.msFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miNew,
            this.miOpen,
            this.miSave,
            this.miExit});
            this.msFile.Name = "msFile";
            this.msFile.Size = new System.Drawing.Size(64, 36);
            this.msFile.Text = "File";
            // 
            // miNew
            // 
            this.miNew.Name = "miNew";
            this.miNew.Size = new System.Drawing.Size(173, 38);
            this.miNew.Text = "New";
            this.miNew.Click += new System.EventHandler(this.miNew_Click);
            // 
            // miOpen
            // 
            this.miOpen.Name = "miOpen";
            this.miOpen.Size = new System.Drawing.Size(173, 38);
            this.miOpen.Text = "Open";
            this.miOpen.Click += new System.EventHandler(this.miOpen_Click);
            // 
            // miSave
            // 
            this.miSave.Name = "miSave";
            this.miSave.Size = new System.Drawing.Size(173, 38);
            this.miSave.Text = "Save";
            this.miSave.Click += new System.EventHandler(this.miSave_Click);
            // 
            // miExit
            // 
            this.miExit.Name = "miExit";
            this.miExit.Size = new System.Drawing.Size(173, 38);
            this.miExit.Text = "Exit";
            this.miExit.Click += new System.EventHandler(this.miExit_Click);
            // 
            // msEdit
            // 
            this.msEdit.Name = "msEdit";
            this.msEdit.Size = new System.Drawing.Size(67, 36);
            this.msEdit.Text = "Edit";
            // 
            // msPreference
            // 
            this.msPreference.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miLanguage});
            this.msPreference.Name = "msPreference";
            this.msPreference.Size = new System.Drawing.Size(141, 36);
            this.msPreference.Text = "Preference";
            // 
            // miLanguage
            // 
            this.miLanguage.Name = "miLanguage";
            this.miLanguage.Size = new System.Drawing.Size(218, 38);
            this.miLanguage.Text = "Language";
            this.miLanguage.Click += new System.EventHandler(this.miLanguage_Click);
            // 
            // msMetrics
            // 
            this.msMetrics.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miFunctionPoints,
            this.miSMI});
            this.msMetrics.Name = "msMetrics";
            this.msMetrics.Size = new System.Drawing.Size(105, 36);
            this.msMetrics.Text = "Metrics";
            // 
            // miFunctionPoints
            // 
            this.miFunctionPoints.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miFPData});
            this.miFunctionPoints.Name = "miFunctionPoints";
            this.miFunctionPoints.Size = new System.Drawing.Size(278, 38);
            this.miFunctionPoints.Text = "Function Points";
            // 
            // miFPData
            // 
            this.miFPData.Name = "miFPData";
            this.miFPData.Size = new System.Drawing.Size(195, 38);
            this.miFPData.Text = "FP Data";
            this.miFPData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.miFPData.Click += new System.EventHandler(this.miFPData_Click);
            // 
            // miSMI
            // 
            this.miSMI.Name = "miSMI";
            this.miSMI.Size = new System.Drawing.Size(278, 38);
            this.miSMI.Text = "SMI";
            this.miSMI.Click += new System.EventHandler(this.miSMI_Click);
            // 
            // msProjectCode
            // 
            this.msProjectCode.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miAddCode,
            this.miProjectCodeStatistics});
            this.msProjectCode.Name = "msProjectCode";
            this.msProjectCode.Size = new System.Drawing.Size(163, 36);
            this.msProjectCode.Text = "Project Code";
            // 
            // miAddCode
            // 
            this.miAddCode.Name = "miAddCode";
            this.miAddCode.Size = new System.Drawing.Size(348, 38);
            this.miAddCode.Text = "Add Code";
            this.miAddCode.Click += new System.EventHandler(this.miAddCode_Click);
            // 
            // miProjectCodeStatistics
            // 
            this.miProjectCodeStatistics.Name = "miProjectCodeStatistics";
            this.miProjectCodeStatistics.Size = new System.Drawing.Size(348, 38);
            this.miProjectCodeStatistics.Text = "Project Code Statistics";
            this.miProjectCodeStatistics.Click += new System.EventHandler(this.miProjectCodeStatistics_Click);
            // 
            // msHelp
            // 
            this.msHelp.Name = "msHelp";
            this.msHelp.Size = new System.Drawing.Size(77, 36);
            this.msHelp.Text = "Help";
            // 
            // tcFunctionPoints
            // 
            this.tcFunctionPoints.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tcFunctionPoints.Location = new System.Drawing.Point(188, 43);
            this.tcFunctionPoints.Name = "tcFunctionPoints";
            this.tcFunctionPoints.SelectedIndex = 0;
            this.tcFunctionPoints.Size = new System.Drawing.Size(915, 826);
            this.tcFunctionPoints.TabIndex = 2;
            // 
            // tvFile
            // 
            this.tvFile.Location = new System.Drawing.Point(0, 43);
            this.tvFile.Name = "tvFile";
            this.tvFile.Size = new System.Drawing.Size(182, 826);
            this.tvFile.TabIndex = 1;
            this.tvFile.Visible = false;
            this.tvFile.MouseUp += new System.Windows.Forms.MouseEventHandler(this.tvFile_MouseUp);
            // 
            // cmsFileMenu
            // 
            this.cmsFileMenu.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.cmsFileMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmOpen,
            this.tsmClose,
            this.tssFileMenu,
            this.tsmDelete});
            this.cmsFileMenu.Name = "cmsFileMenu";
            this.cmsFileMenu.Size = new System.Drawing.Size(161, 118);
            // 
            // tsmOpen
            // 
            this.tsmOpen.Name = "tsmOpen";
            this.tsmOpen.Size = new System.Drawing.Size(300, 36);
            this.tsmOpen.Text = "Open";
            this.tsmOpen.Click += new System.EventHandler(this.tsmOpen_Click);
            // 
            // tsmClose
            // 
            this.tsmClose.Name = "tsmClose";
            this.tsmClose.Size = new System.Drawing.Size(300, 36);
            this.tsmClose.Text = "Close";
            this.tsmClose.Click += new System.EventHandler(this.tsmClose_Click);
            // 
            // tssFileMenu
            // 
            this.tssFileMenu.Name = "tssFileMenu";
            this.tssFileMenu.Size = new System.Drawing.Size(157, 6);
            // 
            // tsmDelete
            // 
            this.tsmDelete.Name = "tsmDelete";
            this.tsmDelete.Size = new System.Drawing.Size(300, 36);
            this.tsmDelete.Text = "Delete";
            this.tsmDelete.Click += new System.EventHandler(this.tsmDelete_Click);
            // 
            // frmMetricsSuite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1103, 869);
            this.Controls.Add(this.tvFile);
            this.Controls.Add(this.tcFunctionPoints);
            this.Controls.Add(this.msMenu);
            this.MainMenuStrip = this.msMenu;
            this.Name = "frmMetricsSuite";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CECS 543 Metrics Suite";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMetricsSuite_FormClosing);
            this.msMenu.ResumeLayout(false);
            this.msMenu.PerformLayout();
            this.cmsFileMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip msMenu;
        private System.Windows.Forms.ToolStripMenuItem msFile;
        private System.Windows.Forms.ToolStripMenuItem msEdit;
        private System.Windows.Forms.ToolStripMenuItem msPreference;
        private System.Windows.Forms.ToolStripMenuItem msMetrics;
        private System.Windows.Forms.ToolStripMenuItem msHelp;
        private System.Windows.Forms.ToolStripMenuItem miNew;
        private System.Windows.Forms.ToolStripMenuItem miOpen;
        private System.Windows.Forms.ToolStripMenuItem miSave;
        private System.Windows.Forms.ToolStripMenuItem miExit;
        private System.Windows.Forms.ToolStripMenuItem miLanguage;
        private System.Windows.Forms.ToolStripMenuItem miFunctionPoints;
        private System.Windows.Forms.ToolStripMenuItem miFPData;
        private System.Windows.Forms.TabControl tcFunctionPoints;
        private System.Windows.Forms.ToolStripMenuItem msProjectCode;
        private System.Windows.Forms.ToolStripMenuItem miSMI;
        private System.Windows.Forms.ToolStripMenuItem miAddCode;
        private System.Windows.Forms.ToolStripMenuItem miProjectCodeStatistics;
        private System.Windows.Forms.TreeView tvFile;
        private System.Windows.Forms.ContextMenuStrip cmsFileMenu;
        private System.Windows.Forms.ToolStripMenuItem tsmOpen;
        private System.Windows.Forms.ToolStripMenuItem tsmClose;
        private System.Windows.Forms.ToolStripSeparator tssFileMenu;
        private System.Windows.Forms.ToolStripMenuItem tsmDelete;
    }
}

