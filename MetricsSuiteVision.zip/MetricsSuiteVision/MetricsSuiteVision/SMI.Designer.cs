﻿namespace MetricsSuiteVision
{
    partial class SMI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lbHeader = new System.Windows.Forms.Label();
            this.dgvSMI = new System.Windows.Forms.DataGridView();
            this.btnAddRow = new System.Windows.Forms.Button();
            this.btnComputeIndex = new System.Windows.Forms.Button();
            this.cSMI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CModuleAdded = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cModuleChanged = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cModuleDeleted = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cTotalModules = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSMI)).BeginInit();
            this.SuspendLayout();
            // 
            // lbHeader
            // 
            this.lbHeader.AutoSize = true;
            this.lbHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeader.Location = new System.Drawing.Point(297, 37);
            this.lbHeader.Name = "lbHeader";
            this.lbHeader.Size = new System.Drawing.Size(343, 33);
            this.lbHeader.TabIndex = 0;
            this.lbHeader.Text = "Software Maturity Index";
            // 
            // dgvSMI
            // 
            this.dgvSMI.AllowUserToAddRows = false;
            this.dgvSMI.AllowUserToDeleteRows = false;
            this.dgvSMI.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgvSMI.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvSMI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSMI.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cSMI,
            this.CModuleAdded,
            this.cModuleChanged,
            this.cModuleDeleted,
            this.cTotalModules});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSMI.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSMI.Location = new System.Drawing.Point(18, 119);
            this.dgvSMI.Name = "dgvSMI";
            this.dgvSMI.RowHeadersVisible = false;
            this.dgvSMI.RowTemplate.Height = 20;
            this.dgvSMI.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSMI.Size = new System.Drawing.Size(928, 493);
            this.dgvSMI.TabIndex = 1;
            this.dgvSMI.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSMI_CellValueChanged);
            this.dgvSMI.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvSMI_EditingControlShowing);
            // 
            // btnAddRow
            // 
            this.btnAddRow.Location = new System.Drawing.Point(79, 667);
            this.btnAddRow.Name = "btnAddRow";
            this.btnAddRow.Size = new System.Drawing.Size(187, 47);
            this.btnAddRow.TabIndex = 2;
            this.btnAddRow.Text = "Add Row";
            this.btnAddRow.UseVisualStyleBackColor = true;
            this.btnAddRow.Click += new System.EventHandler(this.btnAddRow_Click);
            // 
            // btnComputeIndex
            // 
            this.btnComputeIndex.Location = new System.Drawing.Point(675, 667);
            this.btnComputeIndex.Name = "btnComputeIndex";
            this.btnComputeIndex.Size = new System.Drawing.Size(187, 47);
            this.btnComputeIndex.TabIndex = 3;
            this.btnComputeIndex.Text = "Compute Index";
            this.btnComputeIndex.UseVisualStyleBackColor = true;
            this.btnComputeIndex.Click += new System.EventHandler(this.btnComputeIndex_Click);
            // 
            // cSMI
            // 
            this.cSMI.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cSMI.HeaderText = "SMI";
            this.cSMI.Name = "cSMI";
            this.cSMI.ReadOnly = true;
            // 
            // CModuleAdded
            // 
            this.CModuleAdded.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.CModuleAdded.HeaderText = "Modules Added";
            this.CModuleAdded.Name = "CModuleAdded";
            // 
            // cModuleChanged
            // 
            this.cModuleChanged.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cModuleChanged.HeaderText = "Modules Changed";
            this.cModuleChanged.Name = "cModuleChanged";
            // 
            // cModuleDeleted
            // 
            this.cModuleDeleted.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cModuleDeleted.HeaderText = "Modules Deleted";
            this.cModuleDeleted.Name = "cModuleDeleted";
            // 
            // cTotalModules
            // 
            this.cTotalModules.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cTotalModules.HeaderText = "Total Modules";
            this.cTotalModules.Name = "cTotalModules";
            this.cTotalModules.ReadOnly = true;
            // 
            // SMI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.Controls.Add(this.btnComputeIndex);
            this.Controls.Add(this.btnAddRow);
            this.Controls.Add(this.dgvSMI);
            this.Controls.Add(this.lbHeader);
            this.Name = "SMI";
            this.Size = new System.Drawing.Size(973, 793);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSMI)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbHeader;
        private System.Windows.Forms.DataGridView dgvSMI;
        private System.Windows.Forms.Button btnAddRow;
        private System.Windows.Forms.Button btnComputeIndex;
        private System.Windows.Forms.DataGridViewTextBoxColumn cSMI;
        private System.Windows.Forms.DataGridViewTextBoxColumn CModuleAdded;
        private System.Windows.Forms.DataGridViewTextBoxColumn cModuleChanged;
        private System.Windows.Forms.DataGridViewTextBoxColumn cModuleDeleted;
        private System.Windows.Forms.DataGridViewTextBoxColumn cTotalModules;
    }
}
