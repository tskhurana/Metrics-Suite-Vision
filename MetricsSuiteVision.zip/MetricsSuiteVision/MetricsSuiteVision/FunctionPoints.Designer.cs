﻿namespace MetricsSuiteVision
{
    partial class FunctionPoints
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbHeading = new System.Windows.Forms.Label();
            this.lbHeading2 = new System.Windows.Forms.Label();
            this.lbExternalInputs = new System.Windows.Forms.Label();
            this.lbExternalOutputs = new System.Windows.Forms.Label();
            this.lbExternalInquiries = new System.Windows.Forms.Label();
            this.lbInternalLogicalFiles = new System.Windows.Forms.Label();
            this.lbExternalInterfaceFiles = new System.Windows.Forms.Label();
            this.lbTotalCount = new System.Windows.Forms.Label();
            this.txtExternalInputs = new System.Windows.Forms.TextBox();
            this.txtExternalOutputs = new System.Windows.Forms.TextBox();
            this.txtExternalInquiries = new System.Windows.Forms.TextBox();
            this.txtInternalLogicalFiles = new System.Windows.Forms.TextBox();
            this.txtExternalInterfaceFiles = new System.Windows.Forms.TextBox();
            this.gbExternalInputs = new System.Windows.Forms.GroupBox();
            this.rbExternalInputs6 = new System.Windows.Forms.RadioButton();
            this.rbExternalInputs4 = new System.Windows.Forms.RadioButton();
            this.rbExternalInputs3 = new System.Windows.Forms.RadioButton();
            this.gbExternalOutputs = new System.Windows.Forms.GroupBox();
            this.rbExternalOutput7 = new System.Windows.Forms.RadioButton();
            this.rbExternalOutput5 = new System.Windows.Forms.RadioButton();
            this.rbExternalOutput4 = new System.Windows.Forms.RadioButton();
            this.gbExternalInquiries = new System.Windows.Forms.GroupBox();
            this.rbExternalInquiries6 = new System.Windows.Forms.RadioButton();
            this.rbExternalInquiries4 = new System.Windows.Forms.RadioButton();
            this.rbExternalInquiries3 = new System.Windows.Forms.RadioButton();
            this.gbInternalLogicalFiles = new System.Windows.Forms.GroupBox();
            this.rbInternalLogicalFiles15 = new System.Windows.Forms.RadioButton();
            this.rbInternalLogicalFiles10 = new System.Windows.Forms.RadioButton();
            this.rbInternalLogicalFiles7 = new System.Windows.Forms.RadioButton();
            this.gbExternalInterfaceFiles = new System.Windows.Forms.GroupBox();
            this.rbExternalInterfaceFiles10 = new System.Windows.Forms.RadioButton();
            this.rbExternalInterfaceFiles7 = new System.Windows.Forms.RadioButton();
            this.rbExternalInterfaceFiles5 = new System.Windows.Forms.RadioButton();
            this.lbExternalInputsValue = new System.Windows.Forms.Label();
            this.lbExternalOutputsValue = new System.Windows.Forms.Label();
            this.lbExternalInquiriesValue = new System.Windows.Forms.Label();
            this.lbInternalLogicalFilesValue = new System.Windows.Forms.Label();
            this.lbExternalInterfaceFilesValue = new System.Windows.Forms.Label();
            this.lbTotalCountValue = new System.Windows.Forms.Label();
            this.btnComputeFP = new System.Windows.Forms.Button();
            this.btnValueAdjustments = new System.Windows.Forms.Button();
            this.btnComputeCodeSize = new System.Windows.Forms.Button();
            this.btnChangeLanguage = new System.Windows.Forms.Button();
            this.lblCurrentLanguage = new System.Windows.Forms.Label();
            this.lbFuntionPoint = new System.Windows.Forms.Label();
            this.lbValueAdjustments = new System.Windows.Forms.Label();
            this.lbSelectedLanguage = new System.Windows.Forms.Label();
            this.lbCodeSize = new System.Windows.Forms.Label();
            this.gbExternalInputs.SuspendLayout();
            this.gbExternalOutputs.SuspendLayout();
            this.gbExternalInquiries.SuspendLayout();
            this.gbInternalLogicalFiles.SuspendLayout();
            this.gbExternalInterfaceFiles.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbHeading
            // 
            this.lbHeading.AutoSize = true;
            this.lbHeading.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeading.Location = new System.Drawing.Point(367, 29);
            this.lbHeading.Name = "lbHeading";
            this.lbHeading.Size = new System.Drawing.Size(250, 31);
            this.lbHeading.TabIndex = 0;
            this.lbHeading.Text = "Weighting Factors";
            // 
            // lbHeading2
            // 
            this.lbHeading2.AutoSize = true;
            this.lbHeading2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeading2.Location = new System.Drawing.Point(325, 74);
            this.lbHeading2.Name = "lbHeading2";
            this.lbHeading2.Size = new System.Drawing.Size(339, 31);
            this.lbHeading2.TabIndex = 1;
            this.lbHeading2.Text = "Simple Average Complex";
            // 
            // lbExternalInputs
            // 
            this.lbExternalInputs.AutoSize = true;
            this.lbExternalInputs.Location = new System.Drawing.Point(32, 145);
            this.lbExternalInputs.Name = "lbExternalInputs";
            this.lbExternalInputs.Size = new System.Drawing.Size(155, 25);
            this.lbExternalInputs.TabIndex = 2;
            this.lbExternalInputs.Text = "External Inputs";
            // 
            // lbExternalOutputs
            // 
            this.lbExternalOutputs.AutoSize = true;
            this.lbExternalOutputs.Location = new System.Drawing.Point(32, 195);
            this.lbExternalOutputs.Name = "lbExternalOutputs";
            this.lbExternalOutputs.Size = new System.Drawing.Size(172, 25);
            this.lbExternalOutputs.TabIndex = 3;
            this.lbExternalOutputs.Text = "External Outputs";
            // 
            // lbExternalInquiries
            // 
            this.lbExternalInquiries.AutoSize = true;
            this.lbExternalInquiries.Location = new System.Drawing.Point(32, 246);
            this.lbExternalInquiries.Name = "lbExternalInquiries";
            this.lbExternalInquiries.Size = new System.Drawing.Size(178, 25);
            this.lbExternalInquiries.TabIndex = 4;
            this.lbExternalInquiries.Text = "External Inquiries";
            // 
            // lbInternalLogicalFiles
            // 
            this.lbInternalLogicalFiles.AutoSize = true;
            this.lbInternalLogicalFiles.Location = new System.Drawing.Point(32, 296);
            this.lbInternalLogicalFiles.Name = "lbInternalLogicalFiles";
            this.lbInternalLogicalFiles.Size = new System.Drawing.Size(210, 25);
            this.lbInternalLogicalFiles.TabIndex = 5;
            this.lbInternalLogicalFiles.Text = "Internal Logical Files";
            // 
            // lbExternalInterfaceFiles
            // 
            this.lbExternalInterfaceFiles.AutoSize = true;
            this.lbExternalInterfaceFiles.Location = new System.Drawing.Point(32, 349);
            this.lbExternalInterfaceFiles.Name = "lbExternalInterfaceFiles";
            this.lbExternalInterfaceFiles.Size = new System.Drawing.Size(232, 25);
            this.lbExternalInterfaceFiles.TabIndex = 6;
            this.lbExternalInterfaceFiles.Text = "External Interface Files";
            // 
            // lbTotalCount
            // 
            this.lbTotalCount.AutoSize = true;
            this.lbTotalCount.Location = new System.Drawing.Point(32, 416);
            this.lbTotalCount.Name = "lbTotalCount";
            this.lbTotalCount.Size = new System.Drawing.Size(123, 25);
            this.lbTotalCount.TabIndex = 7;
            this.lbTotalCount.Text = "Total Count";
            // 
            // txtExternalInputs
            // 
            this.txtExternalInputs.Location = new System.Drawing.Point(284, 145);
            this.txtExternalInputs.Name = "txtExternalInputs";
            this.txtExternalInputs.Size = new System.Drawing.Size(100, 31);
            this.txtExternalInputs.TabIndex = 8;
            this.txtExternalInputs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtExternalInputs_KeyPress);
            // 
            // txtExternalOutputs
            // 
            this.txtExternalOutputs.Location = new System.Drawing.Point(284, 192);
            this.txtExternalOutputs.Name = "txtExternalOutputs";
            this.txtExternalOutputs.Size = new System.Drawing.Size(100, 31);
            this.txtExternalOutputs.TabIndex = 9;
            this.txtExternalOutputs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtExternalOutputs_KeyPress);
            // 
            // txtExternalInquiries
            // 
            this.txtExternalInquiries.Location = new System.Drawing.Point(284, 243);
            this.txtExternalInquiries.Name = "txtExternalInquiries";
            this.txtExternalInquiries.Size = new System.Drawing.Size(100, 31);
            this.txtExternalInquiries.TabIndex = 10;
            this.txtExternalInquiries.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtExternalInquiries_KeyPress);
            // 
            // txtInternalLogicalFiles
            // 
            this.txtInternalLogicalFiles.Location = new System.Drawing.Point(284, 293);
            this.txtInternalLogicalFiles.Name = "txtInternalLogicalFiles";
            this.txtInternalLogicalFiles.Size = new System.Drawing.Size(100, 31);
            this.txtInternalLogicalFiles.TabIndex = 11;
            this.txtInternalLogicalFiles.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInternalLogicalFiles_KeyPress);
            // 
            // txtExternalInterfaceFiles
            // 
            this.txtExternalInterfaceFiles.Location = new System.Drawing.Point(284, 346);
            this.txtExternalInterfaceFiles.Name = "txtExternalInterfaceFiles";
            this.txtExternalInterfaceFiles.Size = new System.Drawing.Size(100, 31);
            this.txtExternalInterfaceFiles.TabIndex = 12;
            this.txtExternalInterfaceFiles.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtExternalInterfaceFiles_KeyPress);
            // 
            // gbExternalInputs
            // 
            this.gbExternalInputs.Controls.Add(this.rbExternalInputs6);
            this.gbExternalInputs.Controls.Add(this.rbExternalInputs4);
            this.gbExternalInputs.Controls.Add(this.rbExternalInputs3);
            this.gbExternalInputs.Location = new System.Drawing.Point(457, 119);
            this.gbExternalInputs.Name = "gbExternalInputs";
            this.gbExternalInputs.Size = new System.Drawing.Size(227, 57);
            this.gbExternalInputs.TabIndex = 13;
            this.gbExternalInputs.TabStop = false;
            // 
            // rbExternalInputs6
            // 
            this.rbExternalInputs6.AutoSize = true;
            this.rbExternalInputs6.Location = new System.Drawing.Point(143, 19);
            this.rbExternalInputs6.Name = "rbExternalInputs6";
            this.rbExternalInputs6.Size = new System.Drawing.Size(55, 29);
            this.rbExternalInputs6.TabIndex = 2;
            this.rbExternalInputs6.Text = "6";
            this.rbExternalInputs6.UseVisualStyleBackColor = true;
            // 
            // rbExternalInputs4
            // 
            this.rbExternalInputs4.AutoSize = true;
            this.rbExternalInputs4.Checked = true;
            this.rbExternalInputs4.Location = new System.Drawing.Point(79, 19);
            this.rbExternalInputs4.Name = "rbExternalInputs4";
            this.rbExternalInputs4.Size = new System.Drawing.Size(55, 29);
            this.rbExternalInputs4.TabIndex = 1;
            this.rbExternalInputs4.TabStop = true;
            this.rbExternalInputs4.Text = "4";
            this.rbExternalInputs4.UseVisualStyleBackColor = true;
            // 
            // rbExternalInputs3
            // 
            this.rbExternalInputs3.AutoSize = true;
            this.rbExternalInputs3.Location = new System.Drawing.Point(9, 21);
            this.rbExternalInputs3.Name = "rbExternalInputs3";
            this.rbExternalInputs3.Size = new System.Drawing.Size(55, 29);
            this.rbExternalInputs3.TabIndex = 0;
            this.rbExternalInputs3.Text = "3";
            this.rbExternalInputs3.UseVisualStyleBackColor = true;
            // 
            // gbExternalOutputs
            // 
            this.gbExternalOutputs.Controls.Add(this.rbExternalOutput7);
            this.gbExternalOutputs.Controls.Add(this.rbExternalOutput5);
            this.gbExternalOutputs.Controls.Add(this.rbExternalOutput4);
            this.gbExternalOutputs.Location = new System.Drawing.Point(457, 173);
            this.gbExternalOutputs.Name = "gbExternalOutputs";
            this.gbExternalOutputs.Size = new System.Drawing.Size(227, 57);
            this.gbExternalOutputs.TabIndex = 14;
            this.gbExternalOutputs.TabStop = false;
            // 
            // rbExternalOutput7
            // 
            this.rbExternalOutput7.AutoSize = true;
            this.rbExternalOutput7.Location = new System.Drawing.Point(143, 19);
            this.rbExternalOutput7.Name = "rbExternalOutput7";
            this.rbExternalOutput7.Size = new System.Drawing.Size(55, 29);
            this.rbExternalOutput7.TabIndex = 2;
            this.rbExternalOutput7.Text = "7";
            this.rbExternalOutput7.UseVisualStyleBackColor = true;
            // 
            // rbExternalOutput5
            // 
            this.rbExternalOutput5.AutoSize = true;
            this.rbExternalOutput5.Checked = true;
            this.rbExternalOutput5.Location = new System.Drawing.Point(79, 19);
            this.rbExternalOutput5.Name = "rbExternalOutput5";
            this.rbExternalOutput5.Size = new System.Drawing.Size(55, 29);
            this.rbExternalOutput5.TabIndex = 1;
            this.rbExternalOutput5.TabStop = true;
            this.rbExternalOutput5.Text = "5";
            this.rbExternalOutput5.UseVisualStyleBackColor = true;
            // 
            // rbExternalOutput4
            // 
            this.rbExternalOutput4.AutoSize = true;
            this.rbExternalOutput4.Location = new System.Drawing.Point(9, 21);
            this.rbExternalOutput4.Name = "rbExternalOutput4";
            this.rbExternalOutput4.Size = new System.Drawing.Size(55, 29);
            this.rbExternalOutput4.TabIndex = 0;
            this.rbExternalOutput4.Text = "4";
            this.rbExternalOutput4.UseVisualStyleBackColor = true;
            // 
            // gbExternalInquiries
            // 
            this.gbExternalInquiries.Controls.Add(this.rbExternalInquiries6);
            this.gbExternalInquiries.Controls.Add(this.rbExternalInquiries4);
            this.gbExternalInquiries.Controls.Add(this.rbExternalInquiries3);
            this.gbExternalInquiries.Location = new System.Drawing.Point(457, 225);
            this.gbExternalInquiries.Name = "gbExternalInquiries";
            this.gbExternalInquiries.Size = new System.Drawing.Size(227, 57);
            this.gbExternalInquiries.TabIndex = 15;
            this.gbExternalInquiries.TabStop = false;
            // 
            // rbExternalInquiries6
            // 
            this.rbExternalInquiries6.AutoSize = true;
            this.rbExternalInquiries6.Location = new System.Drawing.Point(143, 19);
            this.rbExternalInquiries6.Name = "rbExternalInquiries6";
            this.rbExternalInquiries6.Size = new System.Drawing.Size(55, 29);
            this.rbExternalInquiries6.TabIndex = 2;
            this.rbExternalInquiries6.Text = "6";
            this.rbExternalInquiries6.UseVisualStyleBackColor = true;
            // 
            // rbExternalInquiries4
            // 
            this.rbExternalInquiries4.AutoSize = true;
            this.rbExternalInquiries4.Checked = true;
            this.rbExternalInquiries4.Location = new System.Drawing.Point(79, 19);
            this.rbExternalInquiries4.Name = "rbExternalInquiries4";
            this.rbExternalInquiries4.Size = new System.Drawing.Size(55, 29);
            this.rbExternalInquiries4.TabIndex = 1;
            this.rbExternalInquiries4.TabStop = true;
            this.rbExternalInquiries4.Text = "4";
            this.rbExternalInquiries4.UseVisualStyleBackColor = true;
            // 
            // rbExternalInquiries3
            // 
            this.rbExternalInquiries3.AutoSize = true;
            this.rbExternalInquiries3.Location = new System.Drawing.Point(9, 21);
            this.rbExternalInquiries3.Name = "rbExternalInquiries3";
            this.rbExternalInquiries3.Size = new System.Drawing.Size(55, 29);
            this.rbExternalInquiries3.TabIndex = 0;
            this.rbExternalInquiries3.Text = "3";
            this.rbExternalInquiries3.UseVisualStyleBackColor = true;
            // 
            // gbInternalLogicalFiles
            // 
            this.gbInternalLogicalFiles.Controls.Add(this.rbInternalLogicalFiles15);
            this.gbInternalLogicalFiles.Controls.Add(this.rbInternalLogicalFiles10);
            this.gbInternalLogicalFiles.Controls.Add(this.rbInternalLogicalFiles7);
            this.gbInternalLogicalFiles.Location = new System.Drawing.Point(457, 274);
            this.gbInternalLogicalFiles.Name = "gbInternalLogicalFiles";
            this.gbInternalLogicalFiles.Size = new System.Drawing.Size(227, 57);
            this.gbInternalLogicalFiles.TabIndex = 16;
            this.gbInternalLogicalFiles.TabStop = false;
            // 
            // rbInternalLogicalFiles15
            // 
            this.rbInternalLogicalFiles15.AutoSize = true;
            this.rbInternalLogicalFiles15.Location = new System.Drawing.Point(143, 19);
            this.rbInternalLogicalFiles15.Name = "rbInternalLogicalFiles15";
            this.rbInternalLogicalFiles15.Size = new System.Drawing.Size(67, 29);
            this.rbInternalLogicalFiles15.TabIndex = 2;
            this.rbInternalLogicalFiles15.Text = "15";
            this.rbInternalLogicalFiles15.UseVisualStyleBackColor = true;
            // 
            // rbInternalLogicalFiles10
            // 
            this.rbInternalLogicalFiles10.AutoSize = true;
            this.rbInternalLogicalFiles10.Checked = true;
            this.rbInternalLogicalFiles10.Location = new System.Drawing.Point(79, 19);
            this.rbInternalLogicalFiles10.Name = "rbInternalLogicalFiles10";
            this.rbInternalLogicalFiles10.Size = new System.Drawing.Size(67, 29);
            this.rbInternalLogicalFiles10.TabIndex = 1;
            this.rbInternalLogicalFiles10.TabStop = true;
            this.rbInternalLogicalFiles10.Text = "10";
            this.rbInternalLogicalFiles10.UseVisualStyleBackColor = true;
            // 
            // rbInternalLogicalFiles7
            // 
            this.rbInternalLogicalFiles7.AutoSize = true;
            this.rbInternalLogicalFiles7.Location = new System.Drawing.Point(9, 21);
            this.rbInternalLogicalFiles7.Name = "rbInternalLogicalFiles7";
            this.rbInternalLogicalFiles7.Size = new System.Drawing.Size(55, 29);
            this.rbInternalLogicalFiles7.TabIndex = 0;
            this.rbInternalLogicalFiles7.Text = "7";
            this.rbInternalLogicalFiles7.UseVisualStyleBackColor = true;
            // 
            // gbExternalInterfaceFiles
            // 
            this.gbExternalInterfaceFiles.Controls.Add(this.rbExternalInterfaceFiles10);
            this.gbExternalInterfaceFiles.Controls.Add(this.rbExternalInterfaceFiles7);
            this.gbExternalInterfaceFiles.Controls.Add(this.rbExternalInterfaceFiles5);
            this.gbExternalInterfaceFiles.Location = new System.Drawing.Point(457, 328);
            this.gbExternalInterfaceFiles.Name = "gbExternalInterfaceFiles";
            this.gbExternalInterfaceFiles.Size = new System.Drawing.Size(227, 57);
            this.gbExternalInterfaceFiles.TabIndex = 17;
            this.gbExternalInterfaceFiles.TabStop = false;
            // 
            // rbExternalInterfaceFiles10
            // 
            this.rbExternalInterfaceFiles10.AutoSize = true;
            this.rbExternalInterfaceFiles10.Location = new System.Drawing.Point(143, 19);
            this.rbExternalInterfaceFiles10.Name = "rbExternalInterfaceFiles10";
            this.rbExternalInterfaceFiles10.Size = new System.Drawing.Size(67, 29);
            this.rbExternalInterfaceFiles10.TabIndex = 2;
            this.rbExternalInterfaceFiles10.Text = "10";
            this.rbExternalInterfaceFiles10.UseVisualStyleBackColor = true;
            // 
            // rbExternalInterfaceFiles7
            // 
            this.rbExternalInterfaceFiles7.AutoSize = true;
            this.rbExternalInterfaceFiles7.Checked = true;
            this.rbExternalInterfaceFiles7.Location = new System.Drawing.Point(79, 19);
            this.rbExternalInterfaceFiles7.Name = "rbExternalInterfaceFiles7";
            this.rbExternalInterfaceFiles7.Size = new System.Drawing.Size(55, 29);
            this.rbExternalInterfaceFiles7.TabIndex = 1;
            this.rbExternalInterfaceFiles7.TabStop = true;
            this.rbExternalInterfaceFiles7.Text = "7";
            this.rbExternalInterfaceFiles7.UseVisualStyleBackColor = true;
            // 
            // rbExternalInterfaceFiles5
            // 
            this.rbExternalInterfaceFiles5.AutoSize = true;
            this.rbExternalInterfaceFiles5.Location = new System.Drawing.Point(9, 21);
            this.rbExternalInterfaceFiles5.Name = "rbExternalInterfaceFiles5";
            this.rbExternalInterfaceFiles5.Size = new System.Drawing.Size(55, 29);
            this.rbExternalInterfaceFiles5.TabIndex = 0;
            this.rbExternalInterfaceFiles5.Text = "5";
            this.rbExternalInterfaceFiles5.UseVisualStyleBackColor = true;
            // 
            // lbExternalInputsValue
            // 
            this.lbExternalInputsValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbExternalInputsValue.Location = new System.Drawing.Point(770, 131);
            this.lbExternalInputsValue.Name = "lbExternalInputsValue";
            this.lbExternalInputsValue.Size = new System.Drawing.Size(123, 38);
            this.lbExternalInputsValue.TabIndex = 18;
            // 
            // lbExternalOutputsValue
            // 
            this.lbExternalOutputsValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbExternalOutputsValue.Location = new System.Drawing.Point(770, 184);
            this.lbExternalOutputsValue.Name = "lbExternalOutputsValue";
            this.lbExternalOutputsValue.Size = new System.Drawing.Size(123, 38);
            this.lbExternalOutputsValue.TabIndex = 19;
            // 
            // lbExternalInquiriesValue
            // 
            this.lbExternalInquiriesValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbExternalInquiriesValue.Location = new System.Drawing.Point(770, 236);
            this.lbExternalInquiriesValue.Name = "lbExternalInquiriesValue";
            this.lbExternalInquiriesValue.Size = new System.Drawing.Size(123, 38);
            this.lbExternalInquiriesValue.TabIndex = 20;
            // 
            // lbInternalLogicalFilesValue
            // 
            this.lbInternalLogicalFilesValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbInternalLogicalFilesValue.Location = new System.Drawing.Point(770, 285);
            this.lbInternalLogicalFilesValue.Name = "lbInternalLogicalFilesValue";
            this.lbInternalLogicalFilesValue.Size = new System.Drawing.Size(123, 38);
            this.lbInternalLogicalFilesValue.TabIndex = 21;
            // 
            // lbExternalInterfaceFilesValue
            // 
            this.lbExternalInterfaceFilesValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbExternalInterfaceFilesValue.Location = new System.Drawing.Point(770, 339);
            this.lbExternalInterfaceFilesValue.Name = "lbExternalInterfaceFilesValue";
            this.lbExternalInterfaceFilesValue.Size = new System.Drawing.Size(123, 38);
            this.lbExternalInterfaceFilesValue.TabIndex = 22;
            // 
            // lbTotalCountValue
            // 
            this.lbTotalCountValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTotalCountValue.Location = new System.Drawing.Point(770, 402);
            this.lbTotalCountValue.Name = "lbTotalCountValue";
            this.lbTotalCountValue.Size = new System.Drawing.Size(123, 38);
            this.lbTotalCountValue.TabIndex = 23;
            // 
            // btnComputeFP
            // 
            this.btnComputeFP.Location = new System.Drawing.Point(37, 483);
            this.btnComputeFP.Name = "btnComputeFP";
            this.btnComputeFP.Size = new System.Drawing.Size(150, 53);
            this.btnComputeFP.TabIndex = 24;
            this.btnComputeFP.Text = "Compute FP";
            this.btnComputeFP.UseVisualStyleBackColor = true;
            this.btnComputeFP.Click += new System.EventHandler(this.btnComputeFP_Click);
            // 
            // btnValueAdjustments
            // 
            this.btnValueAdjustments.Location = new System.Drawing.Point(37, 553);
            this.btnValueAdjustments.Name = "btnValueAdjustments";
            this.btnValueAdjustments.Size = new System.Drawing.Size(205, 53);
            this.btnValueAdjustments.TabIndex = 25;
            this.btnValueAdjustments.Text = "Value Adjustments";
            this.btnValueAdjustments.UseVisualStyleBackColor = true;
            this.btnValueAdjustments.Click += new System.EventHandler(this.btnValueAdjustments_Click);
            // 
            // btnComputeCodeSize
            // 
            this.btnComputeCodeSize.Location = new System.Drawing.Point(37, 627);
            this.btnComputeCodeSize.Name = "btnComputeCodeSize";
            this.btnComputeCodeSize.Size = new System.Drawing.Size(227, 53);
            this.btnComputeCodeSize.TabIndex = 26;
            this.btnComputeCodeSize.Text = "Compute Code Size";
            this.btnComputeCodeSize.UseVisualStyleBackColor = true;
            this.btnComputeCodeSize.Click += new System.EventHandler(this.btnComputeCodeSize_Click);
            // 
            // btnChangeLanguage
            // 
            this.btnChangeLanguage.Location = new System.Drawing.Point(37, 698);
            this.btnChangeLanguage.Name = "btnChangeLanguage";
            this.btnChangeLanguage.Size = new System.Drawing.Size(227, 53);
            this.btnChangeLanguage.TabIndex = 27;
            this.btnChangeLanguage.Text = "Change Language";
            this.btnChangeLanguage.UseVisualStyleBackColor = true;
            this.btnChangeLanguage.Click += new System.EventHandler(this.btnChangeLanguage_Click);
            // 
            // lblCurrentLanguage
            // 
            this.lblCurrentLanguage.AutoSize = true;
            this.lblCurrentLanguage.Location = new System.Drawing.Point(368, 629);
            this.lblCurrentLanguage.Name = "lblCurrentLanguage";
            this.lblCurrentLanguage.Size = new System.Drawing.Size(185, 25);
            this.lblCurrentLanguage.TabIndex = 28;
            this.lblCurrentLanguage.Text = "Current Language";
            // 
            // lbFuntionPoint
            // 
            this.lbFuntionPoint.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbFuntionPoint.Location = new System.Drawing.Point(702, 482);
            this.lbFuntionPoint.Name = "lbFuntionPoint";
            this.lbFuntionPoint.Size = new System.Drawing.Size(191, 38);
            this.lbFuntionPoint.TabIndex = 29;
            // 
            // lbValueAdjustments
            // 
            this.lbValueAdjustments.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbValueAdjustments.Location = new System.Drawing.Point(770, 552);
            this.lbValueAdjustments.Name = "lbValueAdjustments";
            this.lbValueAdjustments.Size = new System.Drawing.Size(123, 38);
            this.lbValueAdjustments.TabIndex = 30;
            // 
            // lbSelectedLanguage
            // 
            this.lbSelectedLanguage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbSelectedLanguage.Location = new System.Drawing.Point(559, 628);
            this.lbSelectedLanguage.Name = "lbSelectedLanguage";
            this.lbSelectedLanguage.Size = new System.Drawing.Size(142, 38);
            this.lbSelectedLanguage.TabIndex = 31;
            // 
            // lbCodeSize
            // 
            this.lbCodeSize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbCodeSize.Location = new System.Drawing.Point(751, 627);
            this.lbCodeSize.Name = "lbCodeSize";
            this.lbCodeSize.Size = new System.Drawing.Size(142, 38);
            this.lbCodeSize.TabIndex = 32;
            // 
            // FunctionPoints
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.Controls.Add(this.lbCodeSize);
            this.Controls.Add(this.lbSelectedLanguage);
            this.Controls.Add(this.lbValueAdjustments);
            this.Controls.Add(this.lbFuntionPoint);
            this.Controls.Add(this.lblCurrentLanguage);
            this.Controls.Add(this.btnChangeLanguage);
            this.Controls.Add(this.btnComputeCodeSize);
            this.Controls.Add(this.btnValueAdjustments);
            this.Controls.Add(this.btnComputeFP);
            this.Controls.Add(this.lbTotalCountValue);
            this.Controls.Add(this.lbExternalInterfaceFilesValue);
            this.Controls.Add(this.lbInternalLogicalFilesValue);
            this.Controls.Add(this.lbExternalInquiriesValue);
            this.Controls.Add(this.lbExternalOutputsValue);
            this.Controls.Add(this.lbExternalInputsValue);
            this.Controls.Add(this.gbExternalInterfaceFiles);
            this.Controls.Add(this.gbInternalLogicalFiles);
            this.Controls.Add(this.gbExternalInquiries);
            this.Controls.Add(this.gbExternalOutputs);
            this.Controls.Add(this.gbExternalInputs);
            this.Controls.Add(this.txtExternalInterfaceFiles);
            this.Controls.Add(this.txtInternalLogicalFiles);
            this.Controls.Add(this.txtExternalInquiries);
            this.Controls.Add(this.txtExternalOutputs);
            this.Controls.Add(this.txtExternalInputs);
            this.Controls.Add(this.lbTotalCount);
            this.Controls.Add(this.lbExternalInterfaceFiles);
            this.Controls.Add(this.lbInternalLogicalFiles);
            this.Controls.Add(this.lbExternalInquiries);
            this.Controls.Add(this.lbExternalOutputs);
            this.Controls.Add(this.lbExternalInputs);
            this.Controls.Add(this.lbHeading2);
            this.Controls.Add(this.lbHeading);
            this.Name = "FunctionPoints";
            this.Size = new System.Drawing.Size(973, 793);
            this.gbExternalInputs.ResumeLayout(false);
            this.gbExternalInputs.PerformLayout();
            this.gbExternalOutputs.ResumeLayout(false);
            this.gbExternalOutputs.PerformLayout();
            this.gbExternalInquiries.ResumeLayout(false);
            this.gbExternalInquiries.PerformLayout();
            this.gbInternalLogicalFiles.ResumeLayout(false);
            this.gbInternalLogicalFiles.PerformLayout();
            this.gbExternalInterfaceFiles.ResumeLayout(false);
            this.gbExternalInterfaceFiles.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbHeading;
        private System.Windows.Forms.Label lbHeading2;
        private System.Windows.Forms.Label lbExternalInputs;
        private System.Windows.Forms.Label lbExternalOutputs;
        private System.Windows.Forms.Label lbExternalInquiries;
        private System.Windows.Forms.Label lbInternalLogicalFiles;
        private System.Windows.Forms.Label lbExternalInterfaceFiles;
        private System.Windows.Forms.Label lbTotalCount;
        private System.Windows.Forms.TextBox txtExternalInputs;
        private System.Windows.Forms.TextBox txtExternalOutputs;
        private System.Windows.Forms.TextBox txtExternalInquiries;
        private System.Windows.Forms.TextBox txtInternalLogicalFiles;
        private System.Windows.Forms.TextBox txtExternalInterfaceFiles;
        private System.Windows.Forms.GroupBox gbExternalInputs;
        private System.Windows.Forms.RadioButton rbExternalInputs6;
        private System.Windows.Forms.RadioButton rbExternalInputs4;
        private System.Windows.Forms.RadioButton rbExternalInputs3;
        private System.Windows.Forms.GroupBox gbExternalOutputs;
        private System.Windows.Forms.RadioButton rbExternalOutput7;
        private System.Windows.Forms.RadioButton rbExternalOutput5;
        private System.Windows.Forms.RadioButton rbExternalOutput4;
        private System.Windows.Forms.GroupBox gbExternalInquiries;
        private System.Windows.Forms.RadioButton rbExternalInquiries6;
        private System.Windows.Forms.RadioButton rbExternalInquiries4;
        private System.Windows.Forms.RadioButton rbExternalInquiries3;
        private System.Windows.Forms.GroupBox gbInternalLogicalFiles;
        private System.Windows.Forms.RadioButton rbInternalLogicalFiles15;
        private System.Windows.Forms.RadioButton rbInternalLogicalFiles10;
        private System.Windows.Forms.RadioButton rbInternalLogicalFiles7;
        private System.Windows.Forms.GroupBox gbExternalInterfaceFiles;
        private System.Windows.Forms.RadioButton rbExternalInterfaceFiles10;
        private System.Windows.Forms.RadioButton rbExternalInterfaceFiles7;
        private System.Windows.Forms.RadioButton rbExternalInterfaceFiles5;
        private System.Windows.Forms.Label lbExternalInputsValue;
        private System.Windows.Forms.Label lbExternalOutputsValue;
        private System.Windows.Forms.Label lbExternalInquiriesValue;
        private System.Windows.Forms.Label lbInternalLogicalFilesValue;
        private System.Windows.Forms.Label lbExternalInterfaceFilesValue;
        private System.Windows.Forms.Label lbTotalCountValue;
        private System.Windows.Forms.Button btnComputeFP;
        private System.Windows.Forms.Button btnValueAdjustments;
        private System.Windows.Forms.Button btnComputeCodeSize;
        private System.Windows.Forms.Button btnChangeLanguage;
        private System.Windows.Forms.Label lblCurrentLanguage;
        private System.Windows.Forms.Label lbFuntionPoint;
        private System.Windows.Forms.Label lbValueAdjustments;
        private System.Windows.Forms.Label lbSelectedLanguage;
        private System.Windows.Forms.Label lbCodeSize;
    }
}
