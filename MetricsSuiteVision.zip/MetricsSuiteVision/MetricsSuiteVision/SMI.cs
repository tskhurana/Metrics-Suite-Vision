﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MetricsSuiteVision
{
    public partial class SMI : UserControl
    {
        public int tabIndex;
        public bool _isClosed = true;
        public SMI(SMITable objSMITable = null)
        {
            InitializeComponent();

            if (objSMITable != null)
            {
                for (int i = 0; i < objSMITable.SSMI.Count; i++)
                {
                    dgvSMI.Rows.Add(objSMITable.SSMI[i].DSMI, objSMITable.SSMI[i].DAdded, objSMITable.SSMI[i].DChanged, objSMITable.SSMI[i].DDeleted, objSMITable.SSMI[i].DTotal);
                    if (objSMITable.SSMI.Count > i + 1)
                    {
                        dgvSMI.Rows[i].Cells[1].ReadOnly = true;
                        dgvSMI.Rows[i].Cells[2].ReadOnly = true;
                        dgvSMI.Rows[i].Cells[3].ReadOnly = true;
                    }
                }
                dgvSMI.Update();
            }
        }

        private void btnAddRow_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvSMI.Rows.Count != 0 && dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[0].Value.ToString() != string.Empty)
                {
                    double dSMI = Convert.ToDouble(dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[0].Value.ToString() == string.Empty ?
                        0 : dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[0].Value);
                    double dAdded = Convert.ToDouble(dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[1].Value.ToString() == string.Empty ?
                        0 : dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[1].Value);
                    double dChanged = Convert.ToDouble(dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[2].Value.ToString() == string.Empty ?
                        0 : dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[2].Value);
                    double dDeleted = Convert.ToDouble(dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[3].Value.ToString() == string.Empty ?
                        0 : dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[3].Value);
                    double dTotal = Convert.ToDouble(dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[4].Value.ToString() == string.Empty ?
                        0 : dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[4].Value);

                    dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[4].Value = (dTotal + dAdded - dDeleted).ToString();

                    dTotal = Convert.ToDouble(dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[4].Value.ToString() == string.Empty ?
                        0 : dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[4].Value);

                    SingleSMI singleSMI = new SingleSMI();
                    singleSMI.DSMI = dSMI;
                    singleSMI.DAdded = dAdded;
                    singleSMI.DChanged = dChanged;
                    singleSMI.DTotal = dTotal;
                    singleSMI.DDeleted = dDeleted;
                    SaveSMI(singleSMI, dgvSMI.Rows.Count);
                }
                else if (dgvSMI.Rows.Count != 0)
                {
                    throw new Exception();
                }

                if (dgvSMI.Rows.Count > 1)
                {
                    dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[1].ReadOnly = true;
                    dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[2].ReadOnly = true;
                    dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[3].ReadOnly = true;
                    dgvSMI.Update();
                }

                dgvSMI.Rows.Add(string.Empty, string.Empty, string.Empty, string.Empty, string.Empty);

                foreach (DataGridViewColumn c in dgvSMI.Columns)
                {
                    c.DefaultCellStyle.Font = new Font("Microsoft Sans Serif", 10F, GraphicsUnit.Pixel);
                }
                dgvSMI.CurrentCell = dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[1];
                dgvSMI.BeginEdit(true);
            }
            catch (Exception)
            {
                MessageBox.Show("Calculate previous SMI before adding a new row!!!", "Warning");
            }

        }

        private void dgvSMI_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                double dSMI = Convert.ToDouble(dgvSMI.Rows[e.RowIndex].Cells[0].Value.ToString() == string.Empty ?
                    0 : dgvSMI.Rows[e.RowIndex].Cells[0].Value);
                double dAdded = Convert.ToDouble(dgvSMI.Rows[e.RowIndex].Cells[1].Value.ToString() == string.Empty ?
                    0 : dgvSMI.Rows[e.RowIndex].Cells[1].Value);
                double dChanged = Convert.ToDouble(dgvSMI.Rows[e.RowIndex].Cells[2].Value.ToString() == string.Empty ?
                    0 : dgvSMI.Rows[e.RowIndex].Cells[2].Value);
                double dDeleted = Convert.ToDouble(dgvSMI.Rows[e.RowIndex].Cells[3].Value.ToString() == string.Empty ?
                    0 : dgvSMI.Rows[e.RowIndex].Cells[3].Value);

                double dTotal;
                double dPreviousTotal;
                if (e.RowIndex != 0)
                {
                    dTotal = Convert.ToDouble(dgvSMI.Rows[e.RowIndex].Cells[4].Value.ToString() == string.Empty ?
                        0 : dgvSMI.Rows[e.RowIndex].Cells[4].Value);
                    dPreviousTotal = Convert.ToDouble(dgvSMI.Rows[e.RowIndex - 1].Cells[4].Value.ToString() == string.Empty ?
                        0 : dgvSMI.Rows[e.RowIndex - 1].Cells[4].Value);
                }
                else
                {
                    dTotal = Convert.ToDouble(dgvSMI.Rows[e.RowIndex].Cells[4].Value.ToString() == string.Empty ?
                            0 : dgvSMI.Rows[e.RowIndex].Cells[4].Value);
                    dPreviousTotal = Convert.ToDouble(dgvSMI.Rows[e.RowIndex].Cells[4].Value.ToString() == string.Empty ?
                            0 : dgvSMI.Rows[e.RowIndex].Cells[4].Value);
                }

                if (e.RowIndex > 0)
                {
                    if (e.ColumnIndex == 1)
                    {
                        if (dAdded < 0)
                            dgvSMI.Rows[e.RowIndex].Cells[1].Value = string.Empty;
                    }
                    else if (e.ColumnIndex == 2)
                    {
                        if (dChanged > dTotal)
                            dgvSMI.Rows[e.RowIndex].Cells[2].Value = string.Empty;
                    }
                    else if (e.ColumnIndex == 3)
                        if (dDeleted < 0 || dDeleted > dTotal)
                            dgvSMI.Rows[e.RowIndex].Cells[3].Value = string.Empty;

                    dTotal = dPreviousTotal + dAdded - dDeleted;
                }
                else if (e.RowIndex == 0)
                {
                    if (dAdded < 0)
                        dgvSMI.Rows[e.RowIndex].Cells[1].Value = string.Empty;
                    else
                        dTotal = dAdded;
                }
                
                dgvSMI.Rows[e.RowIndex].Cells[4].Value = dTotal;

                SingleSMI singleSMI = new SingleSMI();
                singleSMI.DSMI = dSMI;
                singleSMI.DAdded = dAdded;
                singleSMI.DChanged = dChanged;
                singleSMI.DTotal = dTotal;
                singleSMI.DDeleted = dDeleted;
                SaveSMI(singleSMI, dgvSMI.Rows.Count);
            }
            catch (Exception)
            {
                //Do Nothing
            }
        }

        private double ComputeSMI()
        {
            double dTotal = Convert.ToDouble(dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[4].Value.ToString() == string.Empty ?
                    dgvSMI.Rows[dgvSMI.Rows.Count - 2].Cells[4].Value : dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[4].Value);
            double dAdded = Convert.ToDouble(dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[1].Value);
            double dChanged = Convert.ToDouble(dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[2].Value);
            double dDeleted = Convert.ToDouble(dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[3].Value);
            return (dTotal - (dAdded + dChanged + dDeleted)) / dTotal;
        }

        private void dgvSMI_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            e.Control.KeyPress -= new KeyPressEventHandler(Column_KeyPress);
            if (dgvSMI.CurrentCell.ColumnIndex == 1 || dgvSMI.CurrentCell.ColumnIndex == 2 || dgvSMI.CurrentCell.ColumnIndex == 3) //Desired Column
            {
                TextBox tb = e.Control as TextBox;
                if (tb != null)
                {
                    tb.KeyPress += new KeyPressEventHandler(Column_KeyPress);
                }
            }
        }

        private void Column_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnComputeIndex_Click(object sender, EventArgs e)
        {
            if (dgvSMI.Rows.Count > 0)
                dgvSMI.Rows[dgvSMI.Rows.Count - 1].Cells[0].Value = ComputeSMI();

            btnAddRow.Focus();
        }

        private void SaveSMI(SingleSMI singleSMI, int index)
        {
            if (frmMetricsSuite.metricsSuiteMain.ObjSMI.SSMI.Count < index)
                frmMetricsSuite.metricsSuiteMain.ObjSMI.SSMI.Add(singleSMI);
            else
            {
                try
                {
                    index--;
                    frmMetricsSuite.metricsSuiteMain.ObjSMI.SSMI[index].DSMI = singleSMI.DSMI;
                    frmMetricsSuite.metricsSuiteMain.ObjSMI.SSMI[index].DAdded = singleSMI.DAdded;
                    frmMetricsSuite.metricsSuiteMain.ObjSMI.SSMI[index].DChanged = singleSMI.DChanged;
                    frmMetricsSuite.metricsSuiteMain.ObjSMI.SSMI[index].DDeleted = singleSMI.DDeleted;
                    frmMetricsSuite.metricsSuiteMain.ObjSMI.SSMI[index].DTotal = singleSMI.DTotal;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
    }
}
