﻿namespace MetricsSuiteVision
{
    partial class ValueAdjustmentFactors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbHeading = new System.Windows.Forms.Label();
            this.lbQuestion1 = new System.Windows.Forms.Label();
            this.lbQuestion2 = new System.Windows.Forms.Label();
            this.lbQuestion3 = new System.Windows.Forms.Label();
            this.lbQuestion4 = new System.Windows.Forms.Label();
            this.lbQuestion5 = new System.Windows.Forms.Label();
            this.lbQuesion6 = new System.Windows.Forms.Label();
            this.lbQuestion7 = new System.Windows.Forms.Label();
            this.lbQuestion8 = new System.Windows.Forms.Label();
            this.lbQuestion9 = new System.Windows.Forms.Label();
            this.lbQuestion10 = new System.Windows.Forms.Label();
            this.lbQuestion11 = new System.Windows.Forms.Label();
            this.lbQuestion12 = new System.Windows.Forms.Label();
            this.lbQuestion13 = new System.Windows.Forms.Label();
            this.lbQuestion14 = new System.Windows.Forms.Label();
            this.btnDone = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.cbQuestion1 = new System.Windows.Forms.ComboBox();
            this.cbQuestion2 = new System.Windows.Forms.ComboBox();
            this.cbQuestion3 = new System.Windows.Forms.ComboBox();
            this.cbQuestion6 = new System.Windows.Forms.ComboBox();
            this.cbQuestion5 = new System.Windows.Forms.ComboBox();
            this.cbQuestion4 = new System.Windows.Forms.ComboBox();
            this.cbQuestion12 = new System.Windows.Forms.ComboBox();
            this.cbQuestion11 = new System.Windows.Forms.ComboBox();
            this.cbQuestion10 = new System.Windows.Forms.ComboBox();
            this.cbQuestion9 = new System.Windows.Forms.ComboBox();
            this.cbQuestion8 = new System.Windows.Forms.ComboBox();
            this.cbQuestion7 = new System.Windows.Forms.ComboBox();
            this.cbQuestion14 = new System.Windows.Forms.ComboBox();
            this.cbQuestion13 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbHeading
            // 
            this.lbHeading.AutoSize = true;
            this.lbHeading.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeading.Location = new System.Drawing.Point(40, 35);
            this.lbHeading.Name = "lbHeading";
            this.lbHeading.Size = new System.Drawing.Size(907, 29);
            this.lbHeading.TabIndex = 0;
            this.lbHeading.Text = "Assign a value from 0 to 5 for each of the following Value Adjustment Factors:";
            // 
            // lbQuestion1
            // 
            this.lbQuestion1.AutoSize = true;
            this.lbQuestion1.Location = new System.Drawing.Point(40, 95);
            this.lbQuestion1.Name = "lbQuestion1";
            this.lbQuestion1.Size = new System.Drawing.Size(622, 25);
            this.lbQuestion1.TabIndex = 1;
            this.lbQuestion1.Text = "Does the sytems require reliable backup and recovery process?";
            // 
            // lbQuestion2
            // 
            this.lbQuestion2.AutoSize = true;
            this.lbQuestion2.Location = new System.Drawing.Point(40, 139);
            this.lbQuestion2.Name = "lbQuestion2";
            this.lbQuestion2.Size = new System.Drawing.Size(912, 25);
            this.lbQuestion2.TabIndex = 2;
            this.lbQuestion2.Text = "Are specialized data communication required to transfer information to or from th" +
    "e application?";
            // 
            // lbQuestion3
            // 
            this.lbQuestion3.AutoSize = true;
            this.lbQuestion3.Location = new System.Drawing.Point(40, 184);
            this.lbQuestion3.Name = "lbQuestion3";
            this.lbQuestion3.Size = new System.Drawing.Size(422, 25);
            this.lbQuestion3.TabIndex = 3;
            this.lbQuestion3.Text = "Are there distributed processing functions?";
            // 
            // lbQuestion4
            // 
            this.lbQuestion4.AutoSize = true;
            this.lbQuestion4.Location = new System.Drawing.Point(40, 225);
            this.lbQuestion4.Name = "lbQuestion4";
            this.lbQuestion4.Size = new System.Drawing.Size(234, 25);
            this.lbQuestion4.TabIndex = 4;
            this.lbQuestion4.Text = "Is performance critical?";
            // 
            // lbQuestion5
            // 
            this.lbQuestion5.AutoSize = true;
            this.lbQuestion5.Location = new System.Drawing.Point(40, 265);
            this.lbQuestion5.Name = "lbQuestion5";
            this.lbQuestion5.Size = new System.Drawing.Size(730, 25);
            this.lbQuestion5.TabIndex = 5;
            this.lbQuestion5.Text = "Will the system run in an existing, heavily utilized operational environment?";
            // 
            // lbQuesion6
            // 
            this.lbQuesion6.AutoSize = true;
            this.lbQuesion6.Location = new System.Drawing.Point(40, 309);
            this.lbQuesion6.Name = "lbQuesion6";
            this.lbQuesion6.Size = new System.Drawing.Size(423, 25);
            this.lbQuesion6.TabIndex = 6;
            this.lbQuesion6.Text = "Does the system require online data entry?";
            // 
            // lbQuestion7
            // 
            this.lbQuestion7.AutoSize = true;
            this.lbQuestion7.Location = new System.Drawing.Point(40, 352);
            this.lbQuestion7.Name = "lbQuestion7";
            this.lbQuestion7.Size = new System.Drawing.Size(992, 25);
            this.lbQuestion7.TabIndex = 7;
            this.lbQuestion7.Text = "Does the online data entry require the input transaction to be built over multipl" +
    "e screens or operations?";
            // 
            // lbQuestion8
            // 
            this.lbQuestion8.AutoSize = true;
            this.lbQuestion8.Location = new System.Drawing.Point(40, 393);
            this.lbQuestion8.Name = "lbQuestion8";
            this.lbQuestion8.Size = new System.Drawing.Size(431, 25);
            this.lbQuestion8.TabIndex = 8;
            this.lbQuestion8.Text = "Are the internal logical files updated online?";
            // 
            // lbQuestion9
            // 
            this.lbQuestion9.AutoSize = true;
            this.lbQuestion9.Location = new System.Drawing.Point(40, 436);
            this.lbQuestion9.Name = "lbQuestion9";
            this.lbQuestion9.Size = new System.Drawing.Size(417, 25);
            this.lbQuestion9.TabIndex = 9;
            this.lbQuestion9.Text = "Are the input, output, files updated online?";
            // 
            // lbQuestion10
            // 
            this.lbQuestion10.AutoSize = true;
            this.lbQuestion10.Location = new System.Drawing.Point(40, 479);
            this.lbQuestion10.Name = "lbQuestion10";
            this.lbQuestion10.Size = new System.Drawing.Size(350, 25);
            this.lbQuestion10.TabIndex = 10;
            this.lbQuestion10.Text = "Is the internal processing complex?";
            // 
            // lbQuestion11
            // 
            this.lbQuestion11.AutoSize = true;
            this.lbQuestion11.Location = new System.Drawing.Point(40, 522);
            this.lbQuestion11.Name = "lbQuestion11";
            this.lbQuestion11.Size = new System.Drawing.Size(366, 25);
            this.lbQuestion11.TabIndex = 14;
            this.lbQuestion11.Text = "Is the code designed to be reusable?";
            // 
            // lbQuestion12
            // 
            this.lbQuestion12.AutoSize = true;
            this.lbQuestion12.Location = new System.Drawing.Point(40, 566);
            this.lbQuestion12.Name = "lbQuestion12";
            this.lbQuestion12.Size = new System.Drawing.Size(535, 25);
            this.lbQuestion12.TabIndex = 13;
            this.lbQuestion12.Text = "Are conversion and installation included in the design?";
            // 
            // lbQuestion13
            // 
            this.lbQuestion13.AutoSize = true;
            this.lbQuestion13.Location = new System.Drawing.Point(40, 607);
            this.lbQuestion13.Name = "lbQuestion13";
            this.lbQuestion13.Size = new System.Drawing.Size(717, 25);
            this.lbQuestion13.TabIndex = 12;
            this.lbQuestion13.Text = "Is the system designed for multiple installations in different organizations?";
            // 
            // lbQuestion14
            // 
            this.lbQuestion14.AutoSize = true;
            this.lbQuestion14.Location = new System.Drawing.Point(40, 654);
            this.lbQuestion14.Name = "lbQuestion14";
            this.lbQuestion14.Size = new System.Drawing.Size(771, 25);
            this.lbQuestion14.TabIndex = 11;
            this.lbQuestion14.Text = "Is the application designed to facilitate change and for ease of use by the user?" +
    "";
            // 
            // btnDone
            // 
            this.btnDone.Location = new System.Drawing.Point(45, 719);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(100, 42);
            this.btnDone.TabIndex = 15;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = true;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(203, 719);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 42);
            this.btnCancel.TabIndex = 16;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // cbQuestion1
            // 
            this.cbQuestion1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion1.FormattingEnabled = true;
            this.cbQuestion1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion1.Location = new System.Drawing.Point(1031, 87);
            this.cbQuestion1.Name = "cbQuestion1";
            this.cbQuestion1.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion1.Sorted = true;
            this.cbQuestion1.TabIndex = 17;
            // 
            // cbQuestion2
            // 
            this.cbQuestion2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion2.FormattingEnabled = true;
            this.cbQuestion2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion2.Location = new System.Drawing.Point(1031, 131);
            this.cbQuestion2.Name = "cbQuestion2";
            this.cbQuestion2.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion2.Sorted = true;
            this.cbQuestion2.TabIndex = 18;
            // 
            // cbQuestion3
            // 
            this.cbQuestion3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion3.FormattingEnabled = true;
            this.cbQuestion3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion3.Location = new System.Drawing.Point(1031, 176);
            this.cbQuestion3.Name = "cbQuestion3";
            this.cbQuestion3.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion3.Sorted = true;
            this.cbQuestion3.TabIndex = 19;
            // 
            // cbQuestion6
            // 
            this.cbQuestion6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion6.FormattingEnabled = true;
            this.cbQuestion6.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion6.Location = new System.Drawing.Point(1031, 301);
            this.cbQuestion6.Name = "cbQuestion6";
            this.cbQuestion6.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion6.Sorted = true;
            this.cbQuestion6.TabIndex = 22;
            // 
            // cbQuestion5
            // 
            this.cbQuestion5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion5.FormattingEnabled = true;
            this.cbQuestion5.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion5.Location = new System.Drawing.Point(1031, 257);
            this.cbQuestion5.Name = "cbQuestion5";
            this.cbQuestion5.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion5.Sorted = true;
            this.cbQuestion5.TabIndex = 21;
            // 
            // cbQuestion4
            // 
            this.cbQuestion4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion4.FormattingEnabled = true;
            this.cbQuestion4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion4.Location = new System.Drawing.Point(1031, 217);
            this.cbQuestion4.Name = "cbQuestion4";
            this.cbQuestion4.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion4.Sorted = true;
            this.cbQuestion4.TabIndex = 20;
            // 
            // cbQuestion12
            // 
            this.cbQuestion12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion12.FormattingEnabled = true;
            this.cbQuestion12.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion12.Location = new System.Drawing.Point(1031, 558);
            this.cbQuestion12.Name = "cbQuestion12";
            this.cbQuestion12.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion12.Sorted = true;
            this.cbQuestion12.TabIndex = 28;
            // 
            // cbQuestion11
            // 
            this.cbQuestion11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion11.FormattingEnabled = true;
            this.cbQuestion11.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion11.Location = new System.Drawing.Point(1031, 514);
            this.cbQuestion11.Name = "cbQuestion11";
            this.cbQuestion11.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion11.Sorted = true;
            this.cbQuestion11.TabIndex = 27;
            // 
            // cbQuestion10
            // 
            this.cbQuestion10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion10.FormattingEnabled = true;
            this.cbQuestion10.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion10.Location = new System.Drawing.Point(1031, 471);
            this.cbQuestion10.Name = "cbQuestion10";
            this.cbQuestion10.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion10.Sorted = true;
            this.cbQuestion10.TabIndex = 26;
            // 
            // cbQuestion9
            // 
            this.cbQuestion9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion9.FormattingEnabled = true;
            this.cbQuestion9.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion9.Location = new System.Drawing.Point(1031, 428);
            this.cbQuestion9.Name = "cbQuestion9";
            this.cbQuestion9.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion9.Sorted = true;
            this.cbQuestion9.TabIndex = 25;
            // 
            // cbQuestion8
            // 
            this.cbQuestion8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion8.FormattingEnabled = true;
            this.cbQuestion8.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion8.Location = new System.Drawing.Point(1031, 385);
            this.cbQuestion8.Name = "cbQuestion8";
            this.cbQuestion8.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion8.Sorted = true;
            this.cbQuestion8.TabIndex = 24;
            // 
            // cbQuestion7
            // 
            this.cbQuestion7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion7.FormattingEnabled = true;
            this.cbQuestion7.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion7.Location = new System.Drawing.Point(1031, 344);
            this.cbQuestion7.Name = "cbQuestion7";
            this.cbQuestion7.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion7.Sorted = true;
            this.cbQuestion7.TabIndex = 23;
            // 
            // cbQuestion14
            // 
            this.cbQuestion14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion14.FormattingEnabled = true;
            this.cbQuestion14.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion14.Location = new System.Drawing.Point(1031, 646);
            this.cbQuestion14.Name = "cbQuestion14";
            this.cbQuestion14.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion14.Sorted = true;
            this.cbQuestion14.TabIndex = 30;
            // 
            // cbQuestion13
            // 
            this.cbQuestion13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQuestion13.FormattingEnabled = true;
            this.cbQuestion13.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbQuestion13.Location = new System.Drawing.Point(1031, 599);
            this.cbQuestion13.Name = "cbQuestion13";
            this.cbQuestion13.Size = new System.Drawing.Size(121, 33);
            this.cbQuestion13.Sorted = true;
            this.cbQuestion13.TabIndex = 29;
            // 
            // ValueAdjustmentFactors
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1164, 791);
            this.Controls.Add(this.cbQuestion14);
            this.Controls.Add(this.cbQuestion13);
            this.Controls.Add(this.cbQuestion12);
            this.Controls.Add(this.cbQuestion11);
            this.Controls.Add(this.cbQuestion10);
            this.Controls.Add(this.cbQuestion9);
            this.Controls.Add(this.cbQuestion8);
            this.Controls.Add(this.cbQuestion7);
            this.Controls.Add(this.cbQuestion6);
            this.Controls.Add(this.cbQuestion5);
            this.Controls.Add(this.cbQuestion4);
            this.Controls.Add(this.cbQuestion3);
            this.Controls.Add(this.cbQuestion2);
            this.Controls.Add(this.cbQuestion1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.lbQuestion11);
            this.Controls.Add(this.lbQuestion12);
            this.Controls.Add(this.lbQuestion13);
            this.Controls.Add(this.lbQuestion14);
            this.Controls.Add(this.lbQuestion10);
            this.Controls.Add(this.lbQuestion9);
            this.Controls.Add(this.lbQuestion8);
            this.Controls.Add(this.lbQuestion7);
            this.Controls.Add(this.lbQuesion6);
            this.Controls.Add(this.lbQuestion5);
            this.Controls.Add(this.lbQuestion4);
            this.Controls.Add(this.lbQuestion3);
            this.Controls.Add(this.lbQuestion2);
            this.Controls.Add(this.lbQuestion1);
            this.Controls.Add(this.lbHeading);
            this.Name = "ValueAdjustmentFactors";
            this.Text = "ValueAdjustmentFactors";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbHeading;
        private System.Windows.Forms.Label lbQuestion1;
        private System.Windows.Forms.Label lbQuestion2;
        private System.Windows.Forms.Label lbQuestion3;
        private System.Windows.Forms.Label lbQuestion4;
        private System.Windows.Forms.Label lbQuestion5;
        private System.Windows.Forms.Label lbQuesion6;
        private System.Windows.Forms.Label lbQuestion7;
        private System.Windows.Forms.Label lbQuestion8;
        private System.Windows.Forms.Label lbQuestion9;
        private System.Windows.Forms.Label lbQuestion10;
        private System.Windows.Forms.Label lbQuestion11;
        private System.Windows.Forms.Label lbQuestion12;
        private System.Windows.Forms.Label lbQuestion13;
        private System.Windows.Forms.Label lbQuestion14;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox cbQuestion1;
        private System.Windows.Forms.ComboBox cbQuestion2;
        private System.Windows.Forms.ComboBox cbQuestion3;
        private System.Windows.Forms.ComboBox cbQuestion6;
        private System.Windows.Forms.ComboBox cbQuestion5;
        private System.Windows.Forms.ComboBox cbQuestion4;
        private System.Windows.Forms.ComboBox cbQuestion12;
        private System.Windows.Forms.ComboBox cbQuestion11;
        private System.Windows.Forms.ComboBox cbQuestion10;
        private System.Windows.Forms.ComboBox cbQuestion9;
        private System.Windows.Forms.ComboBox cbQuestion8;
        private System.Windows.Forms.ComboBox cbQuestion7;
        private System.Windows.Forms.ComboBox cbQuestion14;
        private System.Windows.Forms.ComboBox cbQuestion13;
    }
}