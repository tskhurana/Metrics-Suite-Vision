﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace MetricsSuiteVision
{
    public partial class ValueAdjustmentFactors : Form
    {
        private frmMetricsSuite mainForm = null;
        public ValueAdjustmentFactors()
        {
            InitializeComponent();

            if (frmMetricsSuite.metricsSuiteMain != null)
            {
                if (frmMetricsSuite.metricsSuiteMain == null)
                {
                    foreach (Control c in this.Controls)
                    {
                        if (c is ComboBox)
                            ((ComboBox)c).SelectedIndex = 0;
                    }
                }
            }
        }

        public ValueAdjustmentFactors(Form frmCallingFrom)
        {
            InitializeComponent();

            try
            {

                mainForm = frmCallingFrom as frmMetricsSuite;

                if (frmMetricsSuite.metricsSuiteMain != null)
                {
                    if (frmMetricsSuite.metricsSuiteMain == null)
                    {
                        foreach (Control c in this.Controls)
                        {
                            if (c is ComboBox)
                                ((ComboBox)c).SelectedIndex = 0;
                        }
                    }
                    else
                    {
                        int tabIndex = -1;
                        foreach (Control c in mainForm.Controls)
                        {
                            if (c is TabControl)
                            {
                                TabControl tb = (TabControl)c;
                                tabIndex = tb.SelectedIndex;
                            };
                        }

                        if (tabIndex != -1)
                        {
                            this.cbQuestion1.SelectedIndex = this.cbQuestion1.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf1.ToString());
                            this.cbQuestion2.SelectedIndex = this.cbQuestion2.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf2.ToString());
                            this.cbQuestion3.SelectedIndex = this.cbQuestion3.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf3.ToString());
                            this.cbQuestion4.SelectedIndex = this.cbQuestion4.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf4.ToString());
                            this.cbQuestion5.SelectedIndex = this.cbQuestion5.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf5.ToString());
                            this.cbQuestion6.SelectedIndex = this.cbQuestion6.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf6.ToString());
                            this.cbQuestion7.SelectedIndex = this.cbQuestion7.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf7.ToString());
                            this.cbQuestion8.SelectedIndex = this.cbQuestion8.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf8.ToString());
                            this.cbQuestion9.SelectedIndex = this.cbQuestion9.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf9.ToString());
                            this.cbQuestion10.SelectedIndex = this.cbQuestion10.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf10.ToString());
                            this.cbQuestion11.SelectedIndex = this.cbQuestion11.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf11.ToString());
                            this.cbQuestion12.SelectedIndex = this.cbQuestion12.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf12.ToString());
                            this.cbQuestion13.SelectedIndex = this.cbQuestion13.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf13.ToString());
                            this.cbQuestion14.SelectedIndex = this.cbQuestion14.Items.IndexOf(frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf14.ToString());
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occurred!", "Error Message");
            }
        }
        private void btnDone_Click(object sender, EventArgs e)
        {
            try
            {

                int iSumFI = 0;
                var cbQuestionValues = this.Controls.OfType<ComboBox>();

                int tabIndex = -1;
                TabControl tb = null;

                foreach (Control c in mainForm.Controls)
                {
                    if (c is TabControl)
                    {
                        tb = (TabControl)c;
                        tabIndex = tb.SelectedIndex;
                    };
                }

                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf1 = Convert.ToInt32(cbQuestion1.SelectedItem);
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf2 = Convert.ToInt32(cbQuestion2.SelectedItem);
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf3 = Convert.ToInt32(cbQuestion3.SelectedItem);
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf4 = Convert.ToInt32(cbQuestion4.SelectedItem);
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf5 = Convert.ToInt32(cbQuestion5.SelectedItem);
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf6 = Convert.ToInt32(cbQuestion6.SelectedItem);
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf7 = Convert.ToInt32(cbQuestion7.SelectedItem);
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf8 = Convert.ToInt32(cbQuestion8.SelectedItem);
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf9 = Convert.ToInt32(cbQuestion9.SelectedItem);
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf10 = Convert.ToInt32(cbQuestion10.SelectedItem);
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf11 = Convert.ToInt32(cbQuestion11.SelectedItem);
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf12 = Convert.ToInt32(cbQuestion12.SelectedItem);
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf13 = Convert.ToInt32(cbQuestion13.SelectedItem);
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].Vaf14 = Convert.ToInt32(cbQuestion14.SelectedItem);

                foreach (Control cb in cbQuestionValues)
                {
                    if (cb is ComboBox)
                    {
                        iSumFI = iSumFI + (((ComboBox)cb).SelectedIndex == -1 ? 0 : Convert.ToInt32(((ComboBox)cb).SelectedItem.ToString()));
                    }
                }

                // Saving VAF values in project object            
                frmMetricsSuite.metricsSuiteMain.FunctionPoint[tabIndex].ValueAdjustments = iSumFI;

                foreach (Control c in tb.SelectedTab.Controls)
                {
                    if (c is UserControl && c.Name == "FunctionPoints")
                    {
                        foreach (Control uc in c.Controls)
                        {
                            if (uc is Label && uc.Name == "lbValueAdjustments")
                            {
                                Label lb = (Label)uc;
                                lb.Text = iSumFI.ToString();
                            }
                        }
                    }
                }

                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Unexpected Error Occurred!", "Error Message");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
